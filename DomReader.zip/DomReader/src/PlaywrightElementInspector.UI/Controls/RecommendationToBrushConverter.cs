using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.UI.Controls;

public sealed class RecommendationToBrushConverter : IValueConverter
{
    private static readonly SolidColorBrush High = new(Color.FromRgb(0x1E, 0x8E, 0x3E));
    private static readonly SolidColorBrush Medium = new(Color.FromRgb(0xC9, 0x8A, 0x00));
    private static readonly SolidColorBrush Low = new(Color.FromRgb(0xD9, 0x5A, 0x00));
    private static readonly SolidColorBrush Avoid = new(Color.FromRgb(0xC4, 0x2B, 0x2B));

    public object Convert(object? value, Type targetType, object parameter, CultureInfo culture) => value switch
    {
        RecommendationLevel.High => High,
        RecommendationLevel.Medium => Medium,
        RecommendationLevel.Low => Low,
        RecommendationLevel.Avoid => Avoid,
        _ => Avoid
    };

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}
