using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace PlaywrightElementInspector.UI.Controls;

/// <summary>Empty/whitespace string -> Visible (or Collapsed when ConverterParameter="Invert"); non-empty -> the opposite.</summary>
public sealed class StringEmptyToVisibilityConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object parameter, CultureInfo culture)
    {
        var isEmpty = value is null || string.IsNullOrWhiteSpace((string)value);
        var invert = string.Equals(parameter as string, "Invert", StringComparison.OrdinalIgnoreCase);
        var visible = invert ? !isEmpty : isEmpty;
        return visible ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}
