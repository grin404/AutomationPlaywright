using System.Windows;
using System.Windows.Threading;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using PlaywrightElementInspector.Application.Interfaces;
using PlaywrightElementInspector.Application.Models;
using PlaywrightElementInspector.Application.Services;
using PlaywrightElementInspector.Infrastructure.BrowserManagement;
using PlaywrightElementInspector.Infrastructure.Configuration;
using PlaywrightElementInspector.Infrastructure.Logging;
using PlaywrightElementInspector.Infrastructure.Playwright;
using PlaywrightElementInspector.UI.ViewModels;

namespace PlaywrightElementInspector.UI;

/// <summary>Composition root. Wires Application/Infrastructure services via DI; the rest of the UI only ever sees interfaces.</summary>
public partial class App : System.Windows.Application
{
    private ServiceProvider? _serviceProvider;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        DispatcherUnhandledException += OnDispatcherUnhandledException;

        var services = new ServiceCollection();
        ConfigureServices(services);
        _serviceProvider = services.BuildServiceProvider();

        var mainWindow = _serviceProvider.GetRequiredService<MainWindow>();
        mainWindow.Show();
    }

    private static void ConfigureServices(IServiceCollection services)
    {
        var config = ConfigLoader.Load();
        services.AddSingleton(config);

        services.AddLogging(builder =>
        {
            builder.ClearProviders();
            builder.SetMinimumLevel(LogLevel.Information);
            builder.AddProvider(new FileLoggerProvider());
        });

        // Application layer: pure logic, no live browser dependency.
        services.AddSingleton<ILocatorGenerator, LocatorGenerator>();
        services.AddSingleton<ILocatorScorer, LocatorScorer>();
        services.AddSingleton<ICodeSnippetGenerator, CodeSnippetGenerator>();
        services.AddSingleton<IPageObjectGenerator, PageObjectGenerator>();
        services.AddSingleton<IExportService, ExportService>();

        // Infrastructure layer: talks to Microsoft.Playwright.
        services.AddSingleton<IBrowserManager, PlaywrightBrowserManager>();
        services.AddSingleton<IDomInspector, PlaywrightDomInspector>();
        services.AddSingleton<ILocatorValidator, PlaywrightLocatorValidator>();
        services.AddSingleton<IElementHighlighter, PlaywrightElementHighlighter>();

        services.AddSingleton<MainViewModel>();
        services.AddSingleton<MainWindow>();
    }

    private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        // One bad element/operation must never take the whole app down.
        MessageBox.Show(
            $"An unexpected error occurred:\n\n{e.Exception.Message}",
            "Playwright Element Inspector",
            MessageBoxButton.OK,
            MessageBoxImage.Warning);
        e.Handled = true;
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _serviceProvider?.GetService<MainViewModel>()?.ShutdownCleanup();
        _serviceProvider?.Dispose();
        base.OnExit(e);
    }
}
