using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;
using Microsoft.Win32;
using PlaywrightElementInspector.Application;
using PlaywrightElementInspector.Application.Interfaces;
using PlaywrightElementInspector.Application.Models;
using PlaywrightElementInspector.Infrastructure.Configuration;

namespace PlaywrightElementInspector.UI.ViewModels;

public sealed partial class MainViewModel : ObservableObject
{
    private readonly IBrowserManager _browserManager;
    private readonly IDomInspector _domInspector;
    private readonly ILocatorGenerator _locatorGenerator;
    private readonly ILocatorScorer _locatorScorer;
    private readonly ILocatorValidator _locatorValidator;
    private readonly IElementHighlighter _highlighter;
    private readonly ICodeSnippetGenerator _codeSnippetGenerator;
    private readonly IPageObjectGenerator _pageObjectGenerator;
    private readonly IExportService _exportService;
    private readonly AppConfig _config;
    private readonly ILogger<MainViewModel> _logger;

    private IBrowserSession? _session;
    private IReadOnlyList<InspectedElement> _elements = Array.Empty<InspectedElement>();
    private readonly Dictionary<string, List<LocatorCandidate>> _candidatesByElementId = new();
    private readonly Dictionary<string, ElementTreeItemViewModel> _treeItemsById = new();
    private int _selectionToken;

    public MainViewModel(
        IBrowserManager browserManager,
        IDomInspector domInspector,
        ILocatorGenerator locatorGenerator,
        ILocatorScorer locatorScorer,
        ILocatorValidator locatorValidator,
        IElementHighlighter highlighter,
        ICodeSnippetGenerator codeSnippetGenerator,
        IPageObjectGenerator pageObjectGenerator,
        IExportService exportService,
        AppConfig config,
        ILogger<MainViewModel> logger)
    {
        _browserManager = browserManager;
        _domInspector = domInspector;
        _locatorGenerator = locatorGenerator;
        _locatorScorer = locatorScorer;
        _locatorValidator = locatorValidator;
        _highlighter = highlighter;
        _codeSnippetGenerator = codeSnippetGenerator;
        _pageObjectGenerator = pageObjectGenerator;
        _exportService = exportService;
        _config = config;
        _logger = logger;

        SelectedBrowser = Enum.TryParse<BrowserKind>(config.Browser.DefaultBrowser, true, out var b) ? b : BrowserKind.Chromium;
        Headless = config.Browser.Headless;
    }

    public IReadOnlyList<BrowserKind> AvailableBrowsers { get; } = Enum.GetValues<BrowserKind>();

    [ObservableProperty] private string _urlText = "https://";
    [ObservableProperty] private BrowserKind _selectedBrowser;
    [ObservableProperty] private bool _headless;
    [ObservableProperty] private bool _isBusy;
    [ObservableProperty] private string _statusMessage = "Enter a URL and click Load Page.";
    [ObservableProperty] private bool _isBrowserMissing;
    [ObservableProperty] private string _searchText = "";
    [ObservableProperty] private bool _includeLowValueElements;
    [ObservableProperty] private ElementTreeItemViewModel? _selectedElement;
    [ObservableProperty] private CandidateViewModel? _selectedCandidate;
    [ObservableProperty] private string _outputText = "";
    [ObservableProperty] private string _pageObjectClassName = "GeneratedPage";
    [ObservableProperty] private bool _isSessionActive;

    public ObservableCollection<ElementTreeItemViewModel> RootElements { get; } = new();

    public ObservableCollection<ElementTreeItemViewModel> FilteredElements { get; } = new();

    public ObservableCollection<CandidateViewModel> Candidates { get; } = new();

    partial void OnSearchTextChanged(string value) => ApplyFilter();

    partial void OnSelectedElementChanged(ElementTreeItemViewModel? value) => _ = ValidateAndHighlightAsync(value);

    private InspectorOptions BuildInspectorOptions() => new()
    {
        WaitStrategy = Enum.TryParse<PageReadyStrategy>(_config.Inspector.DefaultWaitStrategy, true, out var s) ? s : PageReadyStrategy.NetworkIdle,
        HighlightElements = _config.Inspector.HighlightElements,
        IncludeLowValueElements = IncludeLowValueElements
    };

    private BrowserLaunchOptions BuildLaunchOptions()
    {
        var storagePath = AppPaths.ResolveBrowserStoragePath(_config.Browser.BrowserStoragePath);
        return new BrowserLaunchOptions
        {
            Browser = SelectedBrowser,
            Headless = Headless,
            BrowserStoragePath = storagePath,
            ExecutablePath = string.IsNullOrWhiteSpace(_config.Browser.ExecutablePath) ? null : _config.Browser.ExecutablePath,
            ViewportWidth = _config.Browser.ViewportWidth,
            ViewportHeight = _config.Browser.ViewportHeight,
            PersistentProfilePath = Path.Combine(AppPaths.ProfilesDirectory, "default")
        };
    }

    [RelayCommand]
    private async Task LoadPageAsync()
    {
        var url = NormalizeUrl(UrlText);
        if (url is null)
        {
            StatusMessage = "Enter a valid http(s) URL.";
            return;
        }

        UrlText = url;
        var storagePath = AppPaths.ResolveBrowserStoragePath(_config.Browser.BrowserStoragePath);

        if (!_browserManager.IsBrowserInstalled(SelectedBrowser, storagePath))
        {
            IsBrowserMissing = true;
            StatusMessage = $"{SelectedBrowser} is not installed at '{storagePath}'. Click Install Browser first.";
            return;
        }

        IsBrowserMissing = false;
        await RunBusyAsync($"Launching {SelectedBrowser}...", async () =>
        {
            if (_session is not null)
            {
                await _session.CloseAsync();
                _session = null;
                IsSessionActive = false;
            }

            _session = await _browserManager.LaunchAsync(BuildLaunchOptions());
            IsSessionActive = true;

            StatusMessage = $"Navigating to {url}...";
            await _session.NavigateAsync(url, BuildInspectorOptions());
            StatusMessage = $"Loaded {url}. Authenticate manually if needed, then click Inspect Page.";
        });
    }

    [RelayCommand]
    private async Task InstallBrowserAsync()
    {
        var storagePath = AppPaths.ResolveBrowserStoragePath(_config.Browser.BrowserStoragePath);
        await RunBusyAsync($"Installing {SelectedBrowser}...", async () =>
        {
            var progress = new Progress<string>(line => StatusMessage = line);
            await _browserManager.InstallBrowserAsync(SelectedBrowser, storagePath, progress);
            IsBrowserMissing = false;
            StatusMessage = $"{SelectedBrowser} installed. Click Load Page.";
        });
    }

    [RelayCommand]
    private async Task InspectAsync()
    {
        if (_session is null)
        {
            StatusMessage = "Load a page first.";
            return;
        }

        await RunBusyAsync("Inspecting rendered DOM...", async () =>
        {
            var elements = await _domInspector.InspectAsync(_session, BuildInspectorOptions());
            _elements = elements;

            _candidatesByElementId.Clear();
            var options = BuildInspectorOptions();
            foreach (var element in elements)
            {
                var candidates = _locatorGenerator.GenerateCandidates(element, options).ToList();
                foreach (var candidate in candidates)
                {
                    _locatorScorer.Score(candidate, element, null);
                }

                _candidatesByElementId[element.InternalId] = candidates.OrderByDescending(c => c.Score).ToList();
            }

            BuildTree(elements);
            StatusMessage = $"Inspected {elements.Count} elements. Select one to see locator candidates.";
        });
    }

    [RelayCommand]
    private async Task ReloadAsync()
    {
        if (_session is null) return;
        await RunBusyAsync("Reloading...", async () =>
        {
            await _session!.ReloadAsync(BuildInspectorOptions());
            StatusMessage = "Reloaded. Click Inspect Page to refresh the element tree.";
        });
    }

    [RelayCommand]
    private async Task BackAsync()
    {
        if (_session is null) return;
        await RunBusyAsync("Navigating back...", async () => await _session!.GoBackAsync());
    }

    [RelayCommand]
    private async Task ForwardAsync()
    {
        if (_session is null) return;
        await RunBusyAsync("Navigating forward...", async () => await _session!.GoForwardAsync());
    }

    /// <summary>Best-effort synchronous cleanup for app shutdown, where WPF gives us no reliable async exit hook.</summary>
    public void ShutdownCleanup()
    {
        if (_session is null)
        {
            return;
        }

        try
        {
            _session.CloseAsync().GetAwaiter().GetResult();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error closing browser session during shutdown.");
        }
    }

    [RelayCommand]
    private async Task CloseBrowserAsync()
    {
        if (_session is null) return;
        await RunBusyAsync("Closing browser...", async () =>
        {
            await _session!.CloseAsync();
            _session = null;
            IsSessionActive = false;
            RootElements.Clear();
            FilteredElements.Clear();
            Candidates.Clear();
            StatusMessage = "Browser closed.";
        });
    }

    [RelayCommand]
    private void CopyLocator()
    {
        if (SelectedCandidate is null) return;
        var text = _codeSnippetGenerator.GenerateLocatorOnly(SelectedCandidate.Candidate);
        SetOutputAndCopy(text);
    }

    [RelayCommand]
    private void CopyAction()
    {
        if (SelectedCandidate is null || SelectedElement is null) return;
        var text = _codeSnippetGenerator.GenerateAction(SelectedCandidate.Candidate, SelectedElement.Element);
        SetOutputAndCopy(text);
    }

    [RelayCommand]
    private void CopyNUnit()
    {
        if (SelectedCandidate is null || SelectedElement is null) return;
        var url = _session?.CurrentUrl ?? UrlText;
        var text = _codeSnippetGenerator.GenerateNUnitTest("GeneratedElementTest", url, SelectedCandidate.Candidate, SelectedElement.Element);
        SetOutputAndCopy(text);
    }

    [RelayCommand]
    private void GeneratePageObject()
    {
        var members = _treeItemsById.Values
            .Where(v => v.IsIncludedInPageObject)
            .Select(v =>
            {
                var best = _candidatesByElementId.TryGetValue(v.Element.InternalId, out var list) && list.Count > 0
                    ? list[0]
                    : null;
                return best is null ? null : new PageObjectMember(BuildPropertyName(v.Element), v.Element, best);
            })
            .Where(m => m is not null)
            .Select(m => m!)
            .ToList();

        if (members.Count == 0)
        {
            StatusMessage = "Check \"Include in Page Object\" on at least one element first.";
            return;
        }

        var text = _pageObjectGenerator.Generate(PageObjectClassName, members);
        SetOutputAndCopy(text);
        StatusMessage = $"Generated page object with {members.Count} member(s).";
    }

    [RelayCommand]
    private void CopyOutput()
    {
        if (string.IsNullOrEmpty(OutputText)) return;
        TrySetClipboard(OutputText);
    }

    [RelayCommand]
    private void ExportJson()
    {
        if (_elements.Count == 0)
        {
            StatusMessage = "Inspect a page first.";
            return;
        }

        var dialog = new SaveFileDialog { Filter = "JSON files (*.json)|*.json", FileName = "inspection.json" };
        if (dialog.ShowDialog() != true) return;

        var json = _exportService.ToJson(_elements, ToReadOnlyCandidates());
        File.WriteAllText(dialog.FileName, json);
        StatusMessage = $"Exported JSON to {dialog.FileName}";
    }

    [RelayCommand]
    private void ExportCsv()
    {
        if (_elements.Count == 0)
        {
            StatusMessage = "Inspect a page first.";
            return;
        }

        var dialog = new SaveFileDialog { Filter = "CSV files (*.csv)|*.csv", FileName = "inspection.csv" };
        if (dialog.ShowDialog() != true) return;

        var csv = _exportService.ToCsv(_elements, ToReadOnlyCandidates());
        File.WriteAllText(dialog.FileName, csv);
        StatusMessage = $"Exported CSV to {dialog.FileName}";
    }

    private IReadOnlyDictionary<string, IReadOnlyList<LocatorCandidate>> ToReadOnlyCandidates() =>
        _candidatesByElementId.ToDictionary(kv => kv.Key, kv => (IReadOnlyList<LocatorCandidate>)kv.Value);

    private void SetOutputAndCopy(string text)
    {
        OutputText = text;
        TrySetClipboard(text);
    }

    private void TrySetClipboard(string text)
    {
        try
        {
            Clipboard.SetText(text);
            StatusMessage = "Copied to clipboard.";
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to set clipboard.");
            StatusMessage = "Generated (clipboard copy failed — copy manually from the output panel).";
        }
    }

    private async Task ValidateAndHighlightAsync(ElementTreeItemViewModel? item)
    {
        var token = ++_selectionToken;
        Candidates.Clear();

        if (item is null || _session is null)
        {
            return;
        }

        if (_config.Inspector.HighlightElements)
        {
            try
            {
                await _highlighter.HighlightAsync(_session, item.Element);
            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex, "Highlight failed.");
            }
        }

        if (token != _selectionToken) return;

        if (!_candidatesByElementId.TryGetValue(item.Element.InternalId, out var candidates))
        {
            return;
        }

        var viewModels = candidates.Select(c => new CandidateViewModel(c)).ToList();
        foreach (var vm in viewModels)
        {
            Candidates.Add(vm);
        }

        foreach (var vm in viewModels)
        {
            if (token != _selectionToken) return;

            try
            {
                var validation = await _locatorValidator.ValidateAsync(_session, item.Element, vm.Candidate);
                vm.Candidate.Validation = validation;
                _locatorScorer.Score(vm.Candidate, item.Element, validation);
                vm.RefreshFromModel();
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Validation failed for candidate {Strategy}.", vm.Candidate.Strategy);
            }
        }

        if (token != _selectionToken) return;

        var resorted = Candidates.OrderByDescending(c => c.Score).ToList();
        Candidates.Clear();
        foreach (var vm in resorted)
        {
            Candidates.Add(vm);
        }

        SelectedCandidate = Candidates.FirstOrDefault(c => c.TargetMatched == true) ?? Candidates.FirstOrDefault();

        // Keep the underlying model's candidate list in the same, now-validated order for export/POM use.
        _candidatesByElementId[item.Element.InternalId] = resorted.Select(c => c.Candidate).ToList();
    }

    private void BuildTree(IReadOnlyList<InspectedElement> elements)
    {
        RootElements.Clear();
        FilteredElements.Clear();
        Candidates.Clear();
        SelectedElement = null;
        _treeItemsById.Clear();

        foreach (var element in elements)
        {
            _treeItemsById[element.InternalId] = new ElementTreeItemViewModel(element);
        }

        foreach (var element in elements)
        {
            var node = _treeItemsById[element.InternalId];
            if (element.ParentId is not null && _treeItemsById.TryGetValue(element.ParentId, out var parent))
            {
                parent.Children.Add(node);
            }
            else
            {
                RootElements.Add(node);
            }
        }

        ApplyFilter();
    }

    private void ApplyFilter()
    {
        FilteredElements.Clear();
        if (string.IsNullOrWhiteSpace(SearchText))
        {
            return;
        }

        var needle = SearchText.Trim();
        var matches = _treeItemsById.Values.Where(v =>
            Matches(v.Element, needle));

        foreach (var m in matches)
        {
            FilteredElements.Add(m);
        }
    }

    private static bool Matches(InspectedElement element, string needle) =>
        Contains(element.Tag, needle) || Contains(element.Role, needle) || Contains(element.AccessibleName, needle) ||
        Contains(element.Text, needle) || Contains(element.Id, needle) || Contains(element.Name, needle) ||
        Contains(element.TestIdValue, needle) || Contains(element.Placeholder, needle);

    private static bool Contains(string? haystack, string needle) =>
        !string.IsNullOrEmpty(haystack) && haystack.Contains(needle, StringComparison.OrdinalIgnoreCase);

    private static string BuildPropertyName(InspectedElement element)
    {
        var raw = element.AccessibleName ?? element.LabelText ?? element.Id ?? element.Name ?? element.Tag;
        var chars = raw.Where(char.IsLetterOrDigit).ToArray();
        var result = new string(chars);
        if (result.Length == 0) result = "Element";
        if (char.IsDigit(result[0])) result = "_" + result;
        return char.ToUpperInvariant(result[0]) + result[1..];
    }

    private static string? NormalizeUrl(string input)
    {
        input = input.Trim();
        if (string.IsNullOrEmpty(input)) return null;

        if (!input.Contains("://"))
        {
            input = "https://" + input;
        }

        return Uri.TryCreate(input, UriKind.Absolute, out var uri) && (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps)
            ? input
            : null;
    }

    private async Task RunBusyAsync(string busyMessage, Func<Task> action)
    {
        IsBusy = true;
        StatusMessage = busyMessage;
        try
        {
            await action();
        }
        catch (PlaywrightElementInspectorException ex)
        {
            StatusMessage = ex.Message;
            _logger.LogWarning(ex, "Operation failed.");
        }
        catch (Exception ex)
        {
            StatusMessage = $"Unexpected error: {ex.Message}";
            _logger.LogError(ex, "Unexpected error during operation.");
        }
        finally
        {
            IsBusy = false;
        }
    }
}
