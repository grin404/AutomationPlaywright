using CommunityToolkit.Mvvm.ComponentModel;
using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.UI.ViewModels;

public sealed class CandidateViewModel : ObservableObject
{
    public LocatorCandidate Candidate { get; }

    public CandidateViewModel(LocatorCandidate candidate)
    {
        Candidate = candidate;
    }

    public LocatorStrategyType Strategy => Candidate.Strategy;

    public string CSharpExpression => Candidate.CSharpExpression;

    public int Score => Candidate.Score;

    public RecommendationLevel Recommendation => Candidate.Recommendation;

    public int MatchCount => Candidate.Validation?.MatchCount ?? -1;

    public bool? TargetMatched => Candidate.Validation?.TargetMatched;

    public string ScoreReasonsText => Candidate.ScoreReasons.Count == 0
        ? "No issues detected."
        : string.Join(Environment.NewLine, Candidate.ScoreReasons);

    public bool IsValidated => Candidate.Validation is not null;

    /// <summary>Raises PropertyChanged for every property so the row refreshes after in-place scoring/validation updates.</summary>
    public void RefreshFromModel() => OnPropertyChanged(string.Empty);
}
