using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.UI.ViewModels;

public sealed partial class ElementTreeItemViewModel : ObservableObject
{
    public InspectedElement Element { get; }

    public ObservableCollection<ElementTreeItemViewModel> Children { get; } = new();

    [ObservableProperty]
    private bool _isExpanded = true;

    [ObservableProperty]
    private bool _isIncludedInPageObject;

    public ElementTreeItemViewModel(InspectedElement element)
    {
        Element = element;
    }

    public string DisplayLabel
    {
        get
        {
            var name = Element.AccessibleName ?? Element.Text ?? Element.Id ?? Element.Name;
            var suffix = string.IsNullOrWhiteSpace(name) ? "" : $" \"{Truncate(name, 40)}\"";
            var role = string.IsNullOrWhiteSpace(Element.Role) ? "" : $" [{Element.Role}]";
            return $"<{Element.Tag}>{role}{suffix}";
        }
    }

    private static string Truncate(string value, int max) =>
        value.Length > max ? value[..max] + "…" : value;
}
