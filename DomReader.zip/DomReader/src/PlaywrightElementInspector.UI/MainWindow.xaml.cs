using System.Windows;
using System.Windows.Controls;
using PlaywrightElementInspector.UI.ViewModels;

namespace PlaywrightElementInspector.UI;

/// <summary>Interaction logic for MainWindow.xaml</summary>
public partial class MainWindow : Window
{
    private readonly MainViewModel _viewModel;

    public MainWindow(MainViewModel viewModel)
    {
        InitializeComponent();
        _viewModel = viewModel;
        DataContext = _viewModel;
    }

    private void ElementTree_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
    {
        _viewModel.SelectedElement = e.NewValue as ElementTreeItemViewModel;
    }
}
