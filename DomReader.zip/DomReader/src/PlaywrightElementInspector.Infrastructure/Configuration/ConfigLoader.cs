using Microsoft.Extensions.Configuration;
using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Infrastructure.Configuration;

/// <summary>Loads AppConfig from appsettings.json beside the executable; writes a default file on first run.</summary>
public static class ConfigLoader
{
    public static AppConfig Load()
    {
        if (!File.Exists(AppPaths.ConfigFilePath))
        {
            WriteDefault();
        }

        var configuration = new ConfigurationBuilder()
            .AddJsonFile(AppPaths.ConfigFilePath, optional: true, reloadOnChange: false)
            .Build();

        var config = new AppConfig();
        configuration.Bind(config);
        return config;
    }

    private static void WriteDefault()
    {
        const string defaultJson = """
        {
          "Browser": {
            "DefaultBrowser": "Chromium",
            "Headless": false,
            "ExecutablePath": "",
            "BrowserStoragePath": "./playwright-browsers",
            "ViewportWidth": 1280,
            "ViewportHeight": 720
          },
          "Inspector": {
            "DefaultWaitStrategy": "NetworkIdle",
            "HighlightElements": true
          }
        }
        """;

        try
        {
            File.WriteAllText(AppPaths.ConfigFilePath, defaultJson);
        }
        catch
        {
            // Executable directory not writable; app proceeds with in-memory defaults.
        }
    }
}
