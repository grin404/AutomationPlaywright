namespace PlaywrightElementInspector.Infrastructure.Configuration;

/// <summary>
/// Resolves every writable path the app uses. Never returns a path under Program Files or another
/// admin-protected location — everything lives beside the executable or under %LOCALAPPDATA%.
/// </summary>
public static class AppPaths
{
    private const string AppFolderName = "PlaywrightElementInspector";

    public static string ExecutableDirectory =>
        AppContext.BaseDirectory;

    public static string ConfigFilePath =>
        Path.Combine(ExecutableDirectory, "appsettings.json");

    public static string LocalAppDataRoot =>
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), AppFolderName);

    public static string LogsDirectory =>
        Path.Combine(LocalAppDataRoot, "Logs");

    public static string ProfilesDirectory =>
        Path.Combine(LocalAppDataRoot, "Profiles");

    /// <summary>Resolves a possibly-relative configured browser storage path to an absolute, writable one.</summary>
    public static string ResolveBrowserStoragePath(string configuredPath)
    {
        if (string.IsNullOrWhiteSpace(configuredPath))
        {
            configuredPath = "./playwright-browsers";
        }

        var candidate = Path.IsPathRooted(configuredPath)
            ? configuredPath
            : Path.GetFullPath(Path.Combine(ExecutableDirectory, configuredPath));

        if (IsWritable(candidate))
        {
            return candidate;
        }

        // Executable directory isn't writable (e.g. Program Files) — fall back to a user-writable location.
        return Path.Combine(LocalAppDataRoot, "playwright-browsers");
    }

    private static bool IsWritable(string directoryPath)
    {
        try
        {
            Directory.CreateDirectory(directoryPath);
            var probe = Path.Combine(directoryPath, $".write-probe-{Guid.NewGuid():N}");
            File.WriteAllText(probe, "");
            File.Delete(probe);
            return true;
        }
        catch
        {
            return false;
        }
    }
}
