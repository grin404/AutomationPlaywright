using Microsoft.Extensions.Logging;
using Microsoft.Playwright;
using PlaywrightElementInspector.Application;
using PlaywrightElementInspector.Application.Interfaces;
using PlaywrightElementInspector.Application.Models;
using PlaywrightElementInspector.Infrastructure.Playwright;

namespace PlaywrightElementInspector.Infrastructure.BrowserManagement;

/// <summary>
/// Detects and installs Playwright browser binaries into a user-writable folder (never the machine-global
/// cache, never anywhere requiring admin rights) and launches sessions against them.
/// </summary>
public sealed class PlaywrightBrowserManager : IBrowserManager
{
    private readonly ILogger<PlaywrightBrowserManager> _logger;

    public PlaywrightBrowserManager(ILogger<PlaywrightBrowserManager> logger)
    {
        _logger = logger;
    }

    public bool IsBrowserInstalled(BrowserKind browser, string browserStoragePath)
    {
        if (!Directory.Exists(browserStoragePath))
        {
            return false;
        }

        var prefix = browser switch
        {
            BrowserKind.Chromium => "chromium",
            BrowserKind.Firefox => "firefox",
            BrowserKind.WebKit => "webkit",
            _ => throw new ArgumentOutOfRangeException(nameof(browser))
        };

        return Directory.EnumerateDirectories(browserStoragePath, $"{prefix}*")
            .Any(dir => Directory.EnumerateFiles(dir, "*", SearchOption.AllDirectories).Any());
    }

    public Task InstallBrowserAsync(BrowserKind browser, string browserStoragePath, IProgress<string>? progress = null, CancellationToken cancellationToken = default)
    {
        Directory.CreateDirectory(browserStoragePath);
        Environment.SetEnvironmentVariable("PLAYWRIGHT_BROWSERS_PATH", browserStoragePath);

        var browserArg = browser switch
        {
            BrowserKind.Chromium => "chromium",
            BrowserKind.Firefox => "firefox",
            BrowserKind.WebKit => "webkit",
            _ => throw new ArgumentOutOfRangeException(nameof(browser))
        };

        progress?.Report($"Installing {browserArg} into {browserStoragePath} ...");

        return Task.Run(() =>
        {
            var writer = new ProgressTextWriter(progress);
            var previousOut = Console.Out;
            Console.SetOut(writer);
            try
            {
                var exitCode = Microsoft.Playwright.Program.Main(new[] { "install", browserArg });
                if (exitCode != 0)
                {
                    throw new PlaywrightElementInspectorException(
                        $"Playwright browser install for '{browserArg}' exited with code {exitCode}. See logs for details.");
                }
            }
            finally
            {
                Console.SetOut(previousOut);
            }

            progress?.Report($"{browserArg} installed.");
        }, cancellationToken);
    }

    public async Task<IBrowserSession> LaunchAsync(BrowserLaunchOptions options, CancellationToken cancellationToken = default)
    {
        Environment.SetEnvironmentVariable("PLAYWRIGHT_BROWSERS_PATH", options.BrowserStoragePath);

        if (!IsBrowserInstalled(options.Browser, options.BrowserStoragePath) && string.IsNullOrWhiteSpace(options.ExecutablePath))
        {
            throw new PlaywrightElementInspectorException(
                $"{options.Browser} is not installed at '{options.BrowserStoragePath}'. Install it first (no administrator rights required).");
        }

        IPlaywright playwright;
        try
        {
            playwright = await Microsoft.Playwright.Playwright.CreateAsync();
        }
        catch (Exception ex)
        {
            throw new PlaywrightElementInspectorException($"Failed to initialize Playwright driver: {ex.Message}", ex);
        }

        var browserType = options.Browser switch
        {
            BrowserKind.Chromium => playwright.Chromium,
            BrowserKind.Firefox => playwright.Firefox,
            BrowserKind.WebKit => playwright.Webkit,
            _ => throw new ArgumentOutOfRangeException(nameof(options))
        };

        var viewport = new ViewportSize { Width = options.ViewportWidth, Height = options.ViewportHeight };

        try
        {
            if (!string.IsNullOrWhiteSpace(options.PersistentProfilePath))
            {
                Directory.CreateDirectory(options.PersistentProfilePath);
                var context = await browserType.LaunchPersistentContextAsync(options.PersistentProfilePath, new BrowserTypeLaunchPersistentContextOptions
                {
                    Headless = options.Headless,
                    ExecutablePath = string.IsNullOrWhiteSpace(options.ExecutablePath) ? null : options.ExecutablePath,
                    ViewportSize = viewport
                });

                var page = context.Pages.Count > 0 ? context.Pages[0] : await context.NewPageAsync();
                return new PlaywrightBrowserSession(playwright, browser: null, context, page, _logger);
            }
            else
            {
                var browser = await browserType.LaunchAsync(new BrowserTypeLaunchOptions
                {
                    Headless = options.Headless,
                    ExecutablePath = string.IsNullOrWhiteSpace(options.ExecutablePath) ? null : options.ExecutablePath
                });

                var context = await browser.NewContextAsync(new BrowserNewContextOptions { ViewportSize = viewport });
                var page = await context.NewPageAsync();
                return new PlaywrightBrowserSession(playwright, browser, context, page, _logger);
            }
        }
        catch (PlaywrightException ex)
        {
            playwright.Dispose();
            throw new PlaywrightElementInspectorException(
                $"Failed to launch {options.Browser}. If this is the first run, install the browser first. Details: {ex.Message}", ex);
        }
    }

    private sealed class ProgressTextWriter : System.IO.TextWriter
    {
        private readonly IProgress<string>? _progress;

        public ProgressTextWriter(IProgress<string>? progress) => _progress = progress;

        public override System.Text.Encoding Encoding => System.Text.Encoding.UTF8;

        public override void WriteLine(string? value)
        {
            if (!string.IsNullOrWhiteSpace(value))
            {
                _progress?.Report(value);
            }
        }

        public override void Write(char value)
        {
            // Playwright's installer writes mostly via WriteLine; ignore char-level writes.
        }
    }
}
