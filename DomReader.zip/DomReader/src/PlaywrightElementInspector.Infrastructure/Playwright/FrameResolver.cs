using Microsoft.Playwright;
using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Infrastructure.Playwright;

/// <summary>Finds the live IFrame matching a captured FrameContext (by URL, falling back to name).</summary>
internal static class FrameResolver
{
    public static IFrame Resolve(PlaywrightBrowserSession session, FrameContext frameContext)
    {
        if (frameContext.IsMainFrame)
        {
            return session.Page.MainFrame;
        }

        var match = session.Frames.FirstOrDefault(f => f.Url == frameContext.Url && f.Name == frameContext.Name)
            ?? session.Frames.FirstOrDefault(f => f.Url == frameContext.Url)
            ?? session.Frames.FirstOrDefault(f => f.Name == frameContext.Name);

        return match ?? throw new InvalidOperationException($"Frame '{frameContext.Url}' is no longer attached to the page.");
    }
}
