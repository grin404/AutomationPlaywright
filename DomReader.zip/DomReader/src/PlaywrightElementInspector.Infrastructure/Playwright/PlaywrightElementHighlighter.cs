using Microsoft.Extensions.Logging;
using Microsoft.Playwright;
using PlaywrightElementInspector.Application.Interfaces;
using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Infrastructure.Playwright;

/// <summary>
/// Draws a reversible outline around the selected element via a scoped stylesheet + data attribute —
/// never inline styles on arbitrary attributes, never a permanent page mutation. Clearing removes both.
/// </summary>
public sealed class PlaywrightElementHighlighter : IElementHighlighter
{
    private const string HighlightAttribute = "data-pw-inspector-highlight";
    private const string StyleElementId = "pw-inspector-highlight-style";

    private const string EnsureStyleScript = $$"""
    () => {
      if (document.getElementById('{{StyleElementId}}')) return;
      const style = document.createElement('style');
      style.id = '{{StyleElementId}}';
      style.textContent = `[{{HighlightAttribute}}="1"] { outline: 3px solid #ff3366 !important; outline-offset: 2px !important; background-color: rgba(255,51,102,0.10) !important; }`;
      document.head.appendChild(style);
    }
    """;

    private const string ClearFrameScript = $$"""
    () => {
      document.querySelectorAll('[{{HighlightAttribute}}]').forEach(el => el.removeAttribute('{{HighlightAttribute}}'));
      const style = document.getElementById('{{StyleElementId}}');
      if (style) style.remove();
    }
    """;

    private readonly ILogger<PlaywrightElementHighlighter> _logger;

    public PlaywrightElementHighlighter(ILogger<PlaywrightElementHighlighter> logger)
    {
        _logger = logger;
    }

    public async Task HighlightAsync(IBrowserSession session, InspectedElement element, CancellationToken cancellationToken = default)
    {
        if (session is not PlaywrightBrowserSession pwSession)
        {
            throw new ArgumentException("Session was not created by this application's browser manager.", nameof(session));
        }

        await ClearHighlightAsync(session, cancellationToken);

        IFrame frame;
        try
        {
            frame = FrameResolver.Resolve(pwSession, element.Frame);
        }
        catch (Exception ex)
        {
            _logger.LogInformation(ex, "Could not highlight element: frame no longer attached.");
            return;
        }

        try
        {
            await frame.EvaluateAsync(EnsureStyleScript);

            var handle = await frame.Locator(RelocateSelectorBuilder.Build(element)).ElementHandleAsync(new LocatorElementHandleOptions { Timeout = 2000 });
            if (handle is null)
            {
                return;
            }

            try
            {
                await handle.EvaluateAsync("(el, attr) => el.setAttribute(attr, '1')", HighlightAttribute);
                await handle.ScrollIntoViewIfNeededAsync();
            }
            finally
            {
                await handle.DisposeAsync();
            }
        }
        catch (TimeoutException)
        {
            _logger.LogInformation("Could not highlight element: no longer present in the DOM.");
        }
        catch (PlaywrightException ex)
        {
            _logger.LogInformation(ex, "Could not highlight element.");
        }
    }

    public async Task ClearHighlightAsync(IBrowserSession session, CancellationToken cancellationToken = default)
    {
        if (session is not PlaywrightBrowserSession pwSession)
        {
            throw new ArgumentException("Session was not created by this application's browser manager.", nameof(session));
        }

        foreach (var frame in pwSession.Frames)
        {
            try
            {
                await frame.EvaluateAsync(ClearFrameScript);
            }
            catch (PlaywrightException)
            {
                // Frame may be cross-origin/detached; nothing to clear there.
            }
        }
    }
}
