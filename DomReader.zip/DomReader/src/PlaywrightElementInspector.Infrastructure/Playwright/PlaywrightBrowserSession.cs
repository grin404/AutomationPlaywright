using Microsoft.Extensions.Logging;
using Microsoft.Playwright;
using PlaywrightElementInspector.Application;
using PlaywrightElementInspector.Application.Interfaces;
using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Infrastructure.Playwright;

/// <summary>
/// Concrete Playwright-backed session. Exposes <see cref="Page"/> and <see cref="Frames"/> internally so
/// other Infrastructure services (inspector, validator, highlighter) can drive the real page — these never
/// leak past this assembly; the Application/UI layers only ever see <see cref="IBrowserSession"/>.
/// </summary>
public sealed class PlaywrightBrowserSession : IBrowserSession
{
    private readonly IPlaywright _playwright;
    private readonly IBrowser? _browser;
    private readonly IBrowserContext _context;
    private readonly ILogger _logger;
    private bool _closed;

    internal PlaywrightBrowserSession(IPlaywright playwright, IBrowser? browser, IBrowserContext context, IPage page, ILogger logger)
    {
        _playwright = playwright;
        _browser = browser;
        _context = context;
        Page = page;
        _logger = logger;
    }

    internal IPage Page { get; }

    internal IReadOnlyList<IFrame> Frames => Page.Frames;

    public string? CurrentUrl => _closed ? null : Page.Url;

    public bool IsClosed => _closed || Page.IsClosed;

    public async Task NavigateAsync(string url, InspectorOptions options, CancellationToken cancellationToken = default)
    {
        try
        {
            await Page.GotoAsync(url, new PageGotoOptions { WaitUntil = WaitUntilState.DOMContentLoaded });
            await SettleAsync(options);
        }
        catch (PlaywrightException ex)
        {
            throw new PlaywrightElementInspectorException($"Failed to navigate to '{url}': {ex.Message}", ex);
        }
        catch (TimeoutException ex)
        {
            throw new PlaywrightElementInspectorException($"Navigation to '{url}' timed out: {ex.Message}", ex);
        }
    }

    public async Task ReloadAsync(InspectorOptions options, CancellationToken cancellationToken = default)
    {
        await Page.ReloadAsync(new PageReloadOptions { WaitUntil = WaitUntilState.DOMContentLoaded });
        await SettleAsync(options);
    }

    public async Task GoBackAsync(CancellationToken cancellationToken = default) =>
        await Page.GoBackAsync();

    public async Task GoForwardAsync(CancellationToken cancellationToken = default) =>
        await Page.GoForwardAsync();

    private async Task SettleAsync(InspectorOptions options)
    {
        try
        {
            switch (options.WaitStrategy)
            {
                case PageReadyStrategy.NetworkIdle:
                    await Page.WaitForLoadStateAsync(LoadState.NetworkIdle, new PageWaitForLoadStateOptions
                    {
                        Timeout = options.NetworkIdleTimeoutMs
                    });
                    break;
                case PageReadyStrategy.FixedDelay:
                    await Task.Delay(options.FixedDelayMs);
                    break;
                case PageReadyStrategy.DomContentLoaded:
                default:
                    break;
            }
        }
        catch (TimeoutException)
        {
            _logger.LogWarning("Page did not reach NetworkIdle within {TimeoutMs}ms; continuing with current DOM state.", options.NetworkIdleTimeoutMs);
        }
    }

    public async Task CloseAsync()
    {
        if (_closed)
        {
            return;
        }

        _closed = true;

        try
        {
            await _context.CloseAsync();
        }
        catch (PlaywrightException ex)
        {
            _logger.LogWarning(ex, "Error closing browser context.");
        }

        if (_browser is not null)
        {
            try
            {
                await _browser.CloseAsync();
            }
            catch (PlaywrightException ex)
            {
                _logger.LogWarning(ex, "Error closing browser.");
            }
        }

        _playwright.Dispose();
    }

    public async ValueTask DisposeAsync() => await CloseAsync();
}
