using Microsoft.Extensions.Logging;
using Microsoft.Playwright;
using PlaywrightElementInspector.Application.Interfaces;
using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Infrastructure.Playwright;

/// <summary>
/// Validates a candidate against the live page it was captured from. Re-locates the original element via
/// its captured absolute XPath, stamps it with a temporary marker attribute, builds the real Playwright
/// ILocator for the candidate, and checks whether the marked node is among its matches. The marker is
/// always removed afterward, whether validation succeeds or throws.
/// </summary>
public sealed class PlaywrightLocatorValidator : ILocatorValidator
{
    private const int MaxMatchesToScan = 25;
    private readonly ILogger<PlaywrightLocatorValidator> _logger;

    public PlaywrightLocatorValidator(ILogger<PlaywrightLocatorValidator> logger)
    {
        _logger = logger;
    }

    public async Task<LocatorValidationResult> ValidateAsync(IBrowserSession session, InspectedElement element, LocatorCandidate candidate, CancellationToken cancellationToken = default)
    {
        if (session is not PlaywrightBrowserSession pwSession)
        {
            throw new ArgumentException("Session was not created by this application's browser manager.", nameof(session));
        }

        IFrame frame;
        try
        {
            frame = FrameResolver.Resolve(pwSession, element.Frame);
        }
        catch (Exception ex)
        {
            return new LocatorValidationResult { Resolved = false, IsStale = true, Error = ex.Message };
        }

        var markerValue = Guid.NewGuid().ToString("N");
        IElementHandle? targetHandle = null;

        try
        {
            targetHandle = await frame.Locator(RelocateSelectorBuilder.Build(element)).ElementHandleAsync(new LocatorElementHandleOptions { Timeout = 2000 });
        }
        catch (TimeoutException)
        {
            return new LocatorValidationResult { Resolved = false, IsStale = true, Error = "Original element could not be re-located (likely removed or replaced since inspection)." };
        }
        catch (PlaywrightException ex)
        {
            return new LocatorValidationResult { Resolved = false, IsStale = true, Error = ex.Message };
        }

        if (targetHandle is null)
        {
            return new LocatorValidationResult { Resolved = false, IsStale = true, Error = "Original element could not be re-located." };
        }

        try
        {
            await targetHandle.EvaluateAsync(
                "(el, arg) => el.setAttribute(arg.attr, arg.value)",
                new { attr = ElementMarker.AttributeName, value = markerValue });

            ILocator locator;
            try
            {
                locator = LocatorBuilder.Build(frame, candidate);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Could not build locator for candidate strategy {Strategy}.", candidate.Strategy);
                return new LocatorValidationResult { Resolved = false, Error = ex.Message };
            }

            int matchCount;
            try
            {
                matchCount = await locator.CountAsync();
            }
            catch (PlaywrightException ex)
            {
                return new LocatorValidationResult { Resolved = false, Error = ex.Message };
            }

            var targetMatched = false;
            bool? isVisible = null;
            bool? isEnabled = null;

            var scanCount = Math.Min(matchCount, MaxMatchesToScan);
            for (var i = 0; i < scanCount; i++)
            {
                var candidateNth = locator.Nth(i);
                string? markerAttr;
                try
                {
                    markerAttr = await candidateNth.GetAttributeAsync(ElementMarker.AttributeName);
                }
                catch (PlaywrightException)
                {
                    continue;
                }

                if (markerAttr == markerValue)
                {
                    targetMatched = true;
                    try
                    {
                        isVisible = await candidateNth.IsVisibleAsync();
                        isEnabled = await candidateNth.IsEnabledAsync();
                    }
                    catch (PlaywrightException)
                    {
                        // Best-effort; leave state flags null if they can't be read.
                    }

                    break;
                }
            }

            return new LocatorValidationResult
            {
                Resolved = true,
                MatchCount = matchCount,
                TargetMatched = targetMatched,
                IsVisible = isVisible,
                IsEnabled = isEnabled
            };
        }
        finally
        {
            try
            {
                await targetHandle.EvaluateAsync(
                    "(el, arg) => el.removeAttribute(arg.attr)",
                    new { attr = ElementMarker.AttributeName });
            }
            catch (PlaywrightException)
            {
                // Element may have detached between stamping and cleanup; nothing more to do.
            }

            await targetHandle.DisposeAsync();
        }
    }
}
