using System.Text.Json;
using Microsoft.Extensions.Logging;
using Microsoft.Playwright;
using PlaywrightElementInspector.Application.Interfaces;
using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Infrastructure.Playwright;

/// <summary>
/// Walks every accessible frame's rendered DOM (including open shadow roots) and returns useful elements.
/// Cross-origin frames that refuse script access are skipped with a logged notice rather than failing
/// the whole inspection; one problematic frame or element never aborts the run.
/// </summary>
public sealed class PlaywrightDomInspector : IDomInspector
{
    private readonly ILogger<PlaywrightDomInspector> _logger;

    public PlaywrightDomInspector(ILogger<PlaywrightDomInspector> logger)
    {
        _logger = logger;
    }

    public async Task<IReadOnlyList<InspectedElement>> InspectAsync(IBrowserSession session, InspectorOptions options, CancellationToken cancellationToken = default)
    {
        if (session is not PlaywrightBrowserSession pwSession)
        {
            throw new ArgumentException("Session was not created by this application's browser manager.", nameof(session));
        }

        var elements = new List<InspectedElement>();
        var frames = pwSession.Frames;
        var mainFrame = pwSession.Page.MainFrame;

        for (var frameIndex = 0; frameIndex < frames.Count; frameIndex++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var frame = frames[frameIndex];

            FrameContext frameContext;
            try
            {
                frameContext = await BuildFrameContextAsync(frame, mainFrame);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Skipping frame {Url}: could not resolve frame context.", frame.Url);
                continue;
            }

            try
            {
                var frameElements = await WalkFrameAsync(frame, frameContext, frameIndex, options);
                elements.AddRange(frameElements);
            }
            catch (PlaywrightException ex)
            {
                _logger.LogWarning(ex, "Skipping frame {Url}: script access denied (likely cross-origin) or frame detached.", frame.Url);
            }
        }

        return elements;
    }

    private static async Task<FrameContext> BuildFrameContextAsync(IFrame frame, IFrame mainFrame)
    {
        if (frame == mainFrame)
        {
            return FrameContextExtensions.MainFrame(frame.Url);
        }

        var framePath = new List<string>();
        var current = frame.ParentFrame;
        while (current is not null)
        {
            framePath.Insert(0, string.IsNullOrEmpty(current.Name) ? current.Url : current.Name);
            current = current.ParentFrame;
        }

        string selectorHint;
        try
        {
            var handle = await frame.FrameElementAsync();
            try
            {
                selectorHint = await handle.EvaluateAsync<string>("""
                el => {
                  if (el.name) return `iframe[name='${el.name}']`;
                  if (el.id) return `iframe#${(window.CSS && CSS.escape) ? CSS.escape(el.id) : el.id}`;
                  const src = el.getAttribute('src');
                  if (src) return `iframe[src='${src}']`;
                  const siblings = el.parentElement ? Array.from(el.parentElement.querySelectorAll('iframe')) : [];
                  const idx = siblings.indexOf(el) + 1;
                  return `iframe:nth-of-type(${idx})`;
                }
                """);
            }
            finally
            {
                await handle.DisposeAsync();
            }
        }
        catch
        {
            selectorHint = string.IsNullOrEmpty(frame.Name) ? "iframe" : $"iframe[name='{frame.Name}']";
        }

        return new FrameContext(false, frame.Name, frame.Url, framePath, selectorHint);
    }

    private static async Task<List<InspectedElement>> WalkFrameAsync(IFrame frame, FrameContext frameContext, int frameIndex, InspectorOptions options)
    {
        var arg = new { testIdAttrs = options.TestIdAttributes, includeLowValue = options.IncludeLowValueElements };
        var json = await frame.EvaluateAsync<JsonElement>(DomWalkerScript.Source, arg);

        var raw = json.EnumerateArray().ToList();
        var elements = new List<InspectedElement>(raw.Count);
        var childrenByParent = new Dictionary<int, List<string>>();

        foreach (var node in raw)
        {
            var tempId = node.GetProperty("tempId").GetInt32();
            var internalId = $"{frameIndex}:{tempId}";
            int? parentTempId = node.GetProperty("parentTempId").ValueKind == JsonValueKind.Number
                ? node.GetProperty("parentTempId").GetInt32()
                : null;

            if (parentTempId.HasValue)
            {
                if (!childrenByParent.TryGetValue(parentTempId.Value, out var list))
                {
                    list = new List<string>();
                    childrenByParent[parentTempId.Value] = list;
                }

                list.Add(internalId);
            }

            var attributes = new Dictionary<string, string>();
            if (node.TryGetProperty("attributes", out var attrsEl) && attrsEl.ValueKind == JsonValueKind.Object)
            {
                foreach (var prop in attrsEl.EnumerateObject())
                {
                    attributes[prop.Name] = prop.Value.GetString() ?? "";
                }
            }

            BoundingBox? box = null;
            if (node.TryGetProperty("boundingBox", out var boxEl) && boxEl.ValueKind == JsonValueKind.Object)
            {
                box = new BoundingBox(
                    boxEl.GetProperty("x").GetDouble(),
                    boxEl.GetProperty("y").GetDouble(),
                    boxEl.GetProperty("width").GetDouble(),
                    boxEl.GetProperty("height").GetDouble());
            }

            var category = Enum.Parse<ElementCategory>(GetString(node, "category") ?? "LowValue");

            elements.Add(new InspectedElement
            {
                InternalId = internalId,
                Frame = frameContext,
                Tag = GetString(node, "tag") ?? "div",
                Role = GetString(node, "role"),
                AccessibleName = GetString(node, "accessibleName"),
                Text = GetString(node, "text"),
                Id = GetString(node, "id"),
                Name = GetString(node, "name"),
                ClassAttribute = GetString(node, "className"),
                InputType = GetString(node, "inputType"),
                Placeholder = GetString(node, "placeholder"),
                Title = GetString(node, "title"),
                AriaLabel = GetString(node, "ariaLabel"),
                AriaLabelledBy = GetString(node, "ariaLabelledBy"),
                TestIdAttributeName = GetString(node, "testIdAttributeName"),
                TestIdValue = GetString(node, "testIdValue"),
                LabelText = GetString(node, "labelText"),
                Attributes = attributes,
                IsVisible = node.GetProperty("isVisible").GetBoolean(),
                IsEnabled = node.GetProperty("isEnabled").GetBoolean(),
                IsPasswordInput = node.GetProperty("isPasswordInput").GetBoolean(),
                BoundingBox = box,
                AbsoluteXPath = GetString(node, "absoluteXPath") ?? "",
                DomDepth = node.GetProperty("domDepth").GetInt32(),
                ParentId = parentTempId.HasValue ? $"{frameIndex}:{parentTempId.Value}" : null,
                IsInShadowDom = node.GetProperty("isInShadowDom").GetBoolean(),
                ShadowHostDescription = GetString(node, "shadowHostDescription"),
                Category = category,
                SiblingIndexOfSameTag = node.GetProperty("siblingIndexOfSameTag").GetInt32(),
                SiblingCountOfSameTag = node.GetProperty("siblingCountOfSameTag").GetInt32()
            });
        }

        // Second pass: attach children now that every InternalId in this frame is known.
        for (var i = 0; i < elements.Count; i++)
        {
            var tempId = int.Parse(elements[i].InternalId.Split(':')[1]);
            if (childrenByParent.TryGetValue(tempId, out var childIds))
            {
                elements[i] = elements[i] with { ChildIds = childIds };
            }
        }

        return elements;
    }

    private static string? GetString(JsonElement node, string property) =>
        node.TryGetProperty(property, out var value) && value.ValueKind == JsonValueKind.String
            ? value.GetString()
            : null;
}
