namespace PlaywrightElementInspector.Infrastructure.Playwright;

/// <summary>
/// Name of a temporary, reversible attribute stamped onto an element's DOM node so validation can tell
/// whether a generated locator's matches include the exact node inspection found. Never part of any
/// generated locator output shown to the user, and always removed again right after use.
/// </summary>
internal static class ElementMarker
{
    public const string AttributeName = "data-pw-inspector-marker";
}
