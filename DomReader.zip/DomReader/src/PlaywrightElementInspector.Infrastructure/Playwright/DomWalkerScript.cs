namespace PlaywrightElementInspector.Infrastructure.Playwright;

/// <summary>
/// The in-page JS walker executed per-frame. Traverses light DOM plus any open shadow roots, classifies
/// nodes, and returns a flat array of plain objects. Kept as a single JS function so it can be handed to
/// Playwright's EvaluateAsync verbatim, with parameters passed through the `arg` object (never via C#
/// string interpolation) to avoid any injection/escaping concerns.
/// </summary>
internal static class DomWalkerScript
{
    public const string Source = """
    (arg) => {
      const testIdAttrs = arg.testIdAttrs || [];
      const includeLowValue = !!arg.includeLowValue;
      const INTERACTIVE_TAGS = new Set(['button','input','textarea','select','option','a','iframe']);
      const results = [];
      let counter = 0;

      function trimText(s, max) {
        if (!s) return null;
        const t = s.replace(/\s+/g, ' ').trim();
        if (!t) return null;
        return t.length > max ? t.slice(0, max) : t;
      }

      function findLabelText(el) {
        if (el.tagName === 'LABEL') return null; // a label describes another control, not itself
        if (el.id) {
          const root = el.getRootNode();
          const escaped = (window.CSS && CSS.escape) ? CSS.escape(el.id) : el.id;
          const forLabel = root.querySelector ? root.querySelector(`label[for='${escaped}']`) : null;
          if (forLabel) {
            const t = trimText(forLabel.textContent, 200);
            if (t) return t;
          }
        }
        const wrapping = el.closest ? el.closest('label') : null;
        if (wrapping) {
          const t = trimText(wrapping.textContent, 200);
          if (t) return t;
        }
        return null;
      }

      function computeAccessibleName(el) {
        const ariaLabel = el.getAttribute('aria-label');
        if (ariaLabel && ariaLabel.trim()) return ariaLabel.trim();

        const labelledBy = el.getAttribute('aria-labelledby');
        if (labelledBy) {
          const root = el.getRootNode();
          const parts = labelledBy.split(/\s+/).map(id => {
            const target = root.getElementById ? root.getElementById(id) : document.getElementById(id);
            return target ? trimText(target.textContent, 200) : null;
          }).filter(Boolean);
          if (parts.length) return parts.join(' ');
        }

        const label = findLabelText(el);
        if (label) return label;

        if (el.tagName === 'IMG') {
          const alt = el.getAttribute('alt');
          if (alt && alt.trim()) return alt.trim();
        }

        if (el.tagName === 'INPUT') {
          const type = (el.getAttribute('type') || '').toLowerCase();
          if ((type === 'submit' || type === 'button') && el.getAttribute('value')) {
            return el.getAttribute('value').trim();
          }
        }

        const title = el.getAttribute('title');
        if (title && title.trim()) return title.trim();

        if (el.tagName === 'BUTTON' || el.tagName === 'A') {
          const t = trimText(el.textContent, 200);
          if (t) return t;
        }

        return null;
      }

      function computeRole(el) {
        const explicit = el.getAttribute('role');
        if (explicit) return explicit.toLowerCase();

        const tag = el.tagName.toLowerCase();
        const type = (el.getAttribute('type') || '').toLowerCase();

        if (tag === 'button') return 'button';
        if (tag === 'a' && el.hasAttribute('href')) return 'link';
        if (tag === 'select') return 'combobox';
        if (tag === 'textarea') return 'textbox';
        if (tag === 'option') return 'option';
        if (tag === 'img') return 'img';
        if (tag === 'input') {
          if (type === 'checkbox') return 'checkbox';
          if (type === 'radio') return 'radio';
          if (type === 'submit' || type === 'button' || type === 'reset') return 'button';
          if (type === 'range') return 'slider';
          if (type === 'search') return 'searchbox';
          if (type === 'hidden') return null;
          return 'textbox';
        }
        if (/^h[1-6]$/.test(tag)) return 'heading';
        return null;
      }

      function isVisible(el) {
        const rect = el.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) return false;
        const view = el.ownerDocument.defaultView;
        if (!view) return false;
        const style = view.getComputedStyle(el);
        if (style.display === 'none' || style.visibility === 'hidden' || parseFloat(style.opacity) === 0) return false;
        return true;
      }

      function absoluteXPath(el) {
        if (el.id) {
          const escaped = el.id.replace(/'/g, "\\'");
          return `//*[@id='${escaped}']`;
        }
        const parts = [];
        let node = el;
        while (node && node.nodeType === 1 && node.tagName.toLowerCase() !== 'html') {
          let index = 1;
          let sibling = node.previousElementSibling;
          while (sibling) {
            if (sibling.tagName === node.tagName) index++;
            sibling = sibling.previousElementSibling;
          }
          parts.unshift(`${node.tagName.toLowerCase()}[${index}]`);
          node = node.parentElement;
        }
        return '/html/' + parts.join('/');
      }

      function walk(root, isShadow, shadowHostDesc, parentTempId, depth) {
        const children = root.children ? Array.from(root.children) : [];
        for (const el of children) {
          const tag = el.tagName.toLowerCase();
          if (tag === 'script' || tag === 'style' || tag === 'noscript') continue;

          const testIdAttrName = testIdAttrs.find(a => el.hasAttribute(a));
          const explicitRole = el.getAttribute('role');
          const ariaLabel = el.getAttribute('aria-label');
          const ariaLabelledBy = el.getAttribute('aria-labelledby');
          const hasId = !!el.id;
          const hasName = !!el.getAttribute('name');
          const isInteractiveTag = INTERACTIVE_TAGS.has(tag);
          const isLabelTag = tag === 'label';
          const hasMeaningfulAlt = tag === 'img' && !!el.getAttribute('alt');
          const isUseful = isInteractiveTag || !!explicitRole || !!testIdAttrName || !!ariaLabel || !!ariaLabelledBy || hasId || hasName || isLabelTag || hasMeaningfulAlt;

          const text = trimText(el.textContent, 120);
          let category;
          if (isUseful) {
            category = isInteractiveTag ? 'Interactive' : 'Semantic';
          } else if (text) {
            category = 'Structural';
          } else {
            category = 'LowValue';
          }

          const shouldInclude = isUseful || includeLowValue;
          let myTempId = null;

          if (shouldInclude) {
            myTempId = counter++;
            const siblingsSameTag = children.filter(c => c.tagName === el.tagName);
            const rect = el.getBoundingClientRect();
            const attrs = {};
            for (const attr of el.attributes) {
              if (attr.name === 'value' || attr.name.startsWith('on')) continue;
              attrs[attr.name] = attr.value.length > 300 ? attr.value.slice(0, 300) : attr.value;
            }

            const isPassword = tag === 'input' && (el.getAttribute('type') || '').toLowerCase() === 'password';

            results.push({
              tempId: myTempId,
              parentTempId: parentTempId,
              tag: tag,
              role: computeRole(el),
              accessibleName: computeAccessibleName(el),
              text: text,
              id: el.id || null,
              name: el.getAttribute('name'),
              className: el.getAttribute('class'),
              inputType: tag === 'input' ? (el.getAttribute('type') || 'text') : null,
              placeholder: el.getAttribute('placeholder'),
              title: el.getAttribute('title'),
              ariaLabel: ariaLabel,
              ariaLabelledBy: ariaLabelledBy,
              testIdAttributeName: testIdAttrName || null,
              testIdValue: testIdAttrName ? el.getAttribute(testIdAttrName) : null,
              labelText: findLabelText(el),
              attributes: attrs,
              isVisible: isVisible(el),
              isEnabled: el.disabled !== true,
              isPasswordInput: isPassword,
              boundingBox: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
              absoluteXPath: absoluteXPath(el),
              domDepth: depth,
              isInShadowDom: isShadow,
              shadowHostDescription: shadowHostDesc,
              category: category,
              siblingIndexOfSameTag: siblingsSameTag.indexOf(el) + 1,
              siblingCountOfSameTag: siblingsSameTag.length
            });
          }

          walk(el, isShadow, shadowHostDesc, myTempId !== null ? myTempId : parentTempId, depth + 1);

          if (el.shadowRoot) {
            const hostDesc = tag + (el.id ? '#' + el.id : (el.className ? '.' + String(el.className).split(' ')[0] : ''));
            walk(el.shadowRoot, true, hostDesc, myTempId !== null ? myTempId : parentTempId, depth + 1);
          }
        }
      }

      walk(document.body || document.documentElement, false, null, null, 0);
      return results;
    }
    """;
}
