using Microsoft.Playwright;
using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Infrastructure.Playwright;

/// <summary>Builds a real Playwright ILocator from a generated candidate's structured fields (not by re-parsing the C# text).</summary>
internal static class LocatorBuilder
{
    public static ILocator Build(IFrame frame, LocatorCandidate candidate) => candidate.Strategy switch
    {
        LocatorStrategyType.Role => frame.GetByRole(ParseAriaRole(candidate.RoleName!), new FrameGetByRoleOptions
        {
            Name = candidate.MatchValue,
            Exact = candidate.Exact
        }),
        LocatorStrategyType.Label => frame.GetByLabel(candidate.MatchValue, new FrameGetByLabelOptions { Exact = candidate.Exact }),
        LocatorStrategyType.TestId => frame.GetByTestId(candidate.MatchValue),
        LocatorStrategyType.Placeholder => frame.GetByPlaceholder(candidate.MatchValue, new FrameGetByPlaceholderOptions { Exact = candidate.Exact }),
        LocatorStrategyType.Text => frame.GetByText(candidate.MatchValue, new FrameGetByTextOptions { Exact = candidate.Exact }),
        LocatorStrategyType.CssId => frame.Locator(candidate.MatchValue),
        LocatorStrategyType.CssAttribute => frame.Locator(candidate.MatchValue),
        LocatorStrategyType.CssClass => frame.Locator(candidate.MatchValue),
        LocatorStrategyType.XPath => frame.Locator("xpath=" + candidate.MatchValue),
        _ => throw new ArgumentOutOfRangeException(nameof(candidate), candidate.Strategy, "Unknown locator strategy.")
    };

    private static AriaRole ParseAriaRole(string role)
    {
        var pascal = char.ToUpperInvariant(role[0]) + role[1..].ToLowerInvariant();
        return Enum.Parse<AriaRole>(pascal, ignoreCase: true);
    }
}
