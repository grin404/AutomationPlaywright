using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Infrastructure.Playwright;

/// <summary>
/// Builds the selector used internally to re-locate an already-inspected element on the live page.
/// Playwright's CSS engine pierces open shadow roots automatically; its XPath engine does not. So an
/// id-based CSS selector is preferred whenever the element has one, falling back to the captured
/// absolute XPath only when no id is available (in which case an element inside a shadow root cannot
/// be reliably re-located — a documented limitation, not a crash).
/// </summary>
internal static class RelocateSelectorBuilder
{
    public static string Build(InspectedElement element) =>
        !string.IsNullOrEmpty(element.Id)
            ? $"#{CssEscapeIdentifier(element.Id)}"
            : "xpath=" + element.AbsoluteXPath;

    private static string CssEscapeIdentifier(string value)
    {
        var chars = value.Select(c => char.IsLetterOrDigit(c) || c is '-' or '_' ? c.ToString() : $"\\{c}");
        return string.Concat(chars);
    }
}
