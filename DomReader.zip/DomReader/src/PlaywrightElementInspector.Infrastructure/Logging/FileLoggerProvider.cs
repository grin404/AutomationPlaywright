using System.Collections.Concurrent;
using Microsoft.Extensions.Logging;
using PlaywrightElementInspector.Infrastructure.Configuration;

namespace PlaywrightElementInspector.Infrastructure.Logging;

public sealed class FileLoggerProvider : ILoggerProvider
{
    private readonly string _logFilePath;
    private readonly ConcurrentDictionary<string, RedactingFileLogger> _loggers = new();

    public FileLoggerProvider()
    {
        Directory.CreateDirectory(AppPaths.LogsDirectory);
        _logFilePath = Path.Combine(AppPaths.LogsDirectory, $"{DateTime.Now:yyyy-MM-dd}.log");
    }

    public ILogger CreateLogger(string categoryName) =>
        _loggers.GetOrAdd(categoryName, name => new RedactingFileLogger(name, _logFilePath));

    public void Dispose() => _loggers.Clear();
}
