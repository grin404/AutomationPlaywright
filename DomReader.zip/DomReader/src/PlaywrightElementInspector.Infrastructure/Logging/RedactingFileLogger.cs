using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;

namespace PlaywrightElementInspector.Infrastructure.Logging;

/// <summary>
/// Writes structured log lines to a daily file under %LOCALAPPDATA%\PlaywrightElementInspector\Logs.
/// Defense-in-depth: redacts any secret-looking key=value pair regardless of what the caller passed in,
/// on top of callers never being expected to log passwords/cookies/tokens in the first place.
/// </summary>
public sealed partial class RedactingFileLogger : ILogger
{
    [GeneratedRegex(@"(?i)(password|passwd|pwd|token|authorization|auth|cookie|secret|apikey|api_key)\s*[:=]\s*\S+")]
    private static partial Regex SecretLikeKeyValueRegex();

    private readonly string _categoryName;
    private readonly string _logFilePath;
    private static readonly object WriteLock = new();

    public RedactingFileLogger(string categoryName, string logFilePath)
    {
        _categoryName = categoryName;
        _logFilePath = logFilePath;
    }

    public IDisposable? BeginScope<TState>(TState state) where TState : notnull => null;

    public bool IsEnabled(LogLevel logLevel) => logLevel != LogLevel.None;

    public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
    {
        if (!IsEnabled(logLevel))
        {
            return;
        }

        var message = formatter(state, exception);
        var redacted = Redact(message);
        var line = $"{DateTimeOffset.Now:yyyy-MM-dd HH:mm:ss.fff zzz} [{logLevel}] {_categoryName}: {redacted}";

        if (exception is not null)
        {
            line += Environment.NewLine + Redact(exception.ToString());
        }

        lock (WriteLock)
        {
            try
            {
                File.AppendAllText(_logFilePath, line + Environment.NewLine);
            }
            catch
            {
                // Logging must never crash the app.
            }
        }
    }

    private static string Redact(string message) =>
        SecretLikeKeyValueRegex().Replace(message, m => $"{m.Groups[1].Value}=***REDACTED***");
}
