using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Application.Interfaces;

/// <summary>Validates a generated candidate against the live page it was captured from.</summary>
public interface ILocatorValidator
{
    Task<LocatorValidationResult> ValidateAsync(IBrowserSession session, InspectedElement element, LocatorCandidate candidate, CancellationToken cancellationToken = default);
}
