using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Application.Interfaces;

/// <summary>Detects/installs Playwright browser binaries into a user-writable folder and launches sessions. No admin rights ever required.</summary>
public interface IBrowserManager
{
    bool IsBrowserInstalled(BrowserKind browser, string browserStoragePath);

    /// <summary>Downloads the given browser's binaries into <paramref name="browserStoragePath"/>. Reports human-readable progress lines.</summary>
    Task InstallBrowserAsync(BrowserKind browser, string browserStoragePath, IProgress<string>? progress = null, CancellationToken cancellationToken = default);

    Task<IBrowserSession> LaunchAsync(BrowserLaunchOptions options, CancellationToken cancellationToken = default);
}
