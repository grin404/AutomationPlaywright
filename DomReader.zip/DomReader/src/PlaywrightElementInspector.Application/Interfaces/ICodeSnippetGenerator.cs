using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Application.Interfaces;

/// <summary>Generates copy-paste-ready C# Playwright snippets from a scored candidate. Pure string templating.</summary>
public interface ICodeSnippetGenerator
{
    string GenerateLocatorOnly(LocatorCandidate candidate);

    string GenerateAction(LocatorCandidate candidate, InspectedElement element);

    string GenerateNUnitTest(string testClassName, string pageUrl, LocatorCandidate candidate, InspectedElement element);
}
