using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Application.Interfaces;

/// <summary>Produces ranked locator candidates for one element. Pure logic — no live page access, unit-testable with synthetic elements.</summary>
public interface ILocatorGenerator
{
    IReadOnlyList<LocatorCandidate> GenerateCandidates(InspectedElement element, InspectorOptions options);
}
