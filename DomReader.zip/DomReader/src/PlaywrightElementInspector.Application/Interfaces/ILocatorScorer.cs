using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Application.Interfaces;

/// <summary>Applies fragility/uniqueness/state adjustments on top of a candidate's baseline score. Pure logic.</summary>
public interface ILocatorScorer
{
    /// <summary>Scores in place: sets Score, Recommendation, and ScoreReasons. Validation may be null (not yet validated).</summary>
    void Score(LocatorCandidate candidate, InspectedElement element, LocatorValidationResult? validation);
}
