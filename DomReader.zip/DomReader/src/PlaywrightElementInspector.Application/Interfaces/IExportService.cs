using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Application.Interfaces;

/// <summary>Serializes inspection results for external use. Never includes password values, cookies, or tokens.</summary>
public interface IExportService
{
    string ToJson(IReadOnlyList<InspectedElement> elements, IReadOnlyDictionary<string, IReadOnlyList<LocatorCandidate>> candidatesByElementId);

    string ToCsv(IReadOnlyList<InspectedElement> elements, IReadOnlyDictionary<string, IReadOnlyList<LocatorCandidate>> candidatesByElementId);
}
