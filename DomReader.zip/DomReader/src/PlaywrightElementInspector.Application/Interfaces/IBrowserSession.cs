using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Application.Interfaces;

/// <summary>
/// A live, navigable browser session. Implemented against Microsoft.Playwright in Infrastructure;
/// the UI layer talks only to this interface, never to Playwright types directly.
/// </summary>
public interface IBrowserSession : IAsyncDisposable
{
    string? CurrentUrl { get; }

    bool IsClosed { get; }

    Task NavigateAsync(string url, InspectorOptions options, CancellationToken cancellationToken = default);

    Task GoBackAsync(CancellationToken cancellationToken = default);

    Task GoForwardAsync(CancellationToken cancellationToken = default);

    Task ReloadAsync(InspectorOptions options, CancellationToken cancellationToken = default);

    Task CloseAsync();
}
