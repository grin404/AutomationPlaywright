using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Application.Interfaces;

/// <summary>Generates a C# Page Object class from a set of selected elements and their chosen candidates.</summary>
public interface IPageObjectGenerator
{
    string Generate(string className, IReadOnlyList<PageObjectMember> members);
}
