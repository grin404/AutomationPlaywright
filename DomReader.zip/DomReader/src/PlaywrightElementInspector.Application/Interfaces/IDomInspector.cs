using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Application.Interfaces;

/// <summary>Walks the fully rendered DOM (main frame, sub-frames, open shadow roots) of a live session and returns useful elements.</summary>
public interface IDomInspector
{
    Task<IReadOnlyList<InspectedElement>> InspectAsync(IBrowserSession session, InspectorOptions options, CancellationToken cancellationToken = default);
}
