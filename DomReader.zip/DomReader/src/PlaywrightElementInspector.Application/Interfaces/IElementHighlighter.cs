using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Application.Interfaces;

/// <summary>Draws/removes a reversible visual highlight around an element in the live browser. Never mutates page content permanently.</summary>
public interface IElementHighlighter
{
    Task HighlightAsync(IBrowserSession session, InspectedElement element, CancellationToken cancellationToken = default);

    Task ClearHighlightAsync(IBrowserSession session, CancellationToken cancellationToken = default);
}
