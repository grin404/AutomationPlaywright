using System.Globalization;
using System.Text;
using System.Text.Json;
using PlaywrightElementInspector.Application.Interfaces;
using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Application.Services;

/// <summary>
/// Serializes inspection results to JSON/CSV. Deliberately projects onto <see cref="ExportedElementRecord"/>,
/// which carries no raw attribute bag and no element value — password contents can never leak through export
/// because they were never captured onto <see cref="InspectedElement"/> in the first place.
/// </summary>
public sealed class ExportService : IExportService
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true
    };

    public string ToJson(IReadOnlyList<InspectedElement> elements, IReadOnlyDictionary<string, IReadOnlyList<LocatorCandidate>> candidatesByElementId)
    {
        var records = elements.Select(e => Project(e, candidatesByElementId)).ToList();
        return JsonSerializer.Serialize(records, JsonOptions);
    }

    public string ToCsv(IReadOnlyList<InspectedElement> elements, IReadOnlyDictionary<string, IReadOnlyList<LocatorCandidate>> candidatesByElementId)
    {
        var sb = new StringBuilder();
        sb.AppendLine("ElementId,Tag,Role,AccessibleName,FrameUrl,Visible,Enabled,Strategy,Locator,Score,Recommendation,MatchCount,TargetMatched");

        foreach (var element in elements)
        {
            var candidates = candidatesByElementId.TryGetValue(element.InternalId, out var list)
                ? list
                : Array.Empty<LocatorCandidate>();

            if (candidates.Count == 0)
            {
                sb.AppendLine(string.Join(',', new[]
                {
                    Csv(element.InternalId), Csv(element.Tag), Csv(element.Role ?? ""), Csv(element.AccessibleName ?? ""),
                    Csv(element.Frame.Url), element.IsVisible.ToString(), element.IsEnabled.ToString(),
                    "", "", "", "", "", ""
                }));
                continue;
            }

            foreach (var candidate in candidates)
            {
                sb.AppendLine(string.Join(',', new[]
                {
                    Csv(element.InternalId), Csv(element.Tag), Csv(element.Role ?? ""), Csv(element.AccessibleName ?? ""),
                    Csv(element.Frame.Url), element.IsVisible.ToString(), element.IsEnabled.ToString(),
                    Csv(candidate.Strategy.ToString()), Csv(candidate.CSharpExpression),
                    candidate.Score.ToString(CultureInfo.InvariantCulture), Csv(candidate.Recommendation.ToString()),
                    (candidate.Validation?.MatchCount ?? 0).ToString(CultureInfo.InvariantCulture),
                    (candidate.Validation?.TargetMatched ?? false).ToString()
                }));
            }
        }

        return sb.ToString();
    }

    private static ExportedElementRecord Project(InspectedElement element, IReadOnlyDictionary<string, IReadOnlyList<LocatorCandidate>> candidatesByElementId)
    {
        var candidates = candidatesByElementId.TryGetValue(element.InternalId, out var list)
            ? list
            : Array.Empty<LocatorCandidate>();

        var candidateRecords = candidates
            .OrderByDescending(c => c.Score)
            .Select(c => new ExportedCandidateRecord(
                c.Strategy.ToString(),
                c.CSharpExpression,
                c.Score,
                c.Recommendation.ToString(),
                c.Validation?.MatchCount ?? 0,
                c.Validation?.TargetMatched ?? false,
                c.ScoreReasons))
            .ToList();

        return new ExportedElementRecord(
            element.InternalId,
            element.Tag,
            element.Role,
            element.AccessibleName,
            element.Frame.Url,
            element.IsVisible,
            element.IsEnabled,
            candidateRecords);
    }

    private static string Csv(string value)
    {
        if (value.Contains(',') || value.Contains('"') || value.Contains('\n'))
        {
            return "\"" + value.Replace("\"", "\"\"") + "\"";
        }

        return value;
    }
}
