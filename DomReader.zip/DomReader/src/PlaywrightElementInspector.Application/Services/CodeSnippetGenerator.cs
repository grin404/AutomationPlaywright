using System.Text;
using PlaywrightElementInspector.Application.Interfaces;
using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Application.Services;

/// <summary>Turns a scored candidate into copy-paste-ready C# Playwright snippets. Pure string templating.</summary>
public sealed class CodeSnippetGenerator : ICodeSnippetGenerator
{
    public string GenerateLocatorOnly(LocatorCandidate candidate) => candidate.CSharpExpression;

    public string GenerateAction(LocatorCandidate candidate, InspectedElement element)
    {
        var (method, args) = ResolveAction(element);
        return $"await {candidate.CSharpExpression}.{method}Async({args});";
    }

    public string GenerateNUnitTest(string testClassName, string pageUrl, LocatorCandidate candidate, InspectedElement element)
    {
        var pageExpr = AdaptExpressionToPageVariable(candidate.CSharpExpression, "_page");
        var (method, args) = ResolveAction(element);
        var methodName = $"{SanitizeIdentifier(element.Tag)}_{SanitizeIdentifier(element.AccessibleName ?? element.Text ?? "Element")}_Test";

        var sb = new StringBuilder();
        sb.AppendLine("using Microsoft.Playwright;");
        sb.AppendLine("using NUnit.Framework;");
        sb.AppendLine();
        sb.AppendLine("namespace GeneratedTests;");
        sb.AppendLine();
        sb.AppendLine("[TestFixture]");
        sb.AppendLine($"public class {SanitizeIdentifier(testClassName)}");
        sb.AppendLine("{");
        sb.AppendLine("    private IPlaywright _playwright = null!;");
        sb.AppendLine("    private IBrowser _browser = null!;");
        sb.AppendLine("    private IPage _page = null!;");
        sb.AppendLine();
        sb.AppendLine("    [SetUp]");
        sb.AppendLine("    public async Task SetUp()");
        sb.AppendLine("    {");
        sb.AppendLine("        _playwright = await Playwright.CreateAsync();");
        sb.AppendLine("        _browser = await _playwright.Chromium.LaunchAsync(new BrowserTypeLaunchOptions { Headless = true });");
        sb.AppendLine("        _page = await _browser.NewPageAsync();");
        sb.AppendLine("    }");
        sb.AppendLine();
        sb.AppendLine("    [TearDown]");
        sb.AppendLine("    public async Task TearDown()");
        sb.AppendLine("    {");
        sb.AppendLine("        await _browser.CloseAsync();");
        sb.AppendLine("        _playwright.Dispose();");
        sb.AppendLine("    }");
        sb.AppendLine();
        sb.AppendLine("    [Test]");
        sb.AppendLine($"    public async Task {methodName}()");
        sb.AppendLine("    {");
        sb.AppendLine($"        await _page.GotoAsync(\"{pageUrl}\");");
        sb.AppendLine();
        sb.AppendLine($"        var element = {pageExpr};");
        sb.AppendLine("        Assert.That(await element.IsVisibleAsync(), Is.True);");
        sb.AppendLine($"        await element.{method}Async({args});");
        sb.AppendLine("    }");
        sb.AppendLine("}");

        return sb.ToString();
    }

    private static (string Method, string Args) ResolveAction(InspectedElement element)
    {
        var tag = element.Tag.ToLowerInvariant();
        var type = element.InputType?.ToLowerInvariant();

        if (tag == "input" && type is "checkbox" or "radio")
        {
            return ("Check", "");
        }

        if (tag == "select")
        {
            return ("SelectOption", "new SelectOptionValue { Label = \"REPLACE_WITH_OPTION\" }");
        }

        if ((tag is "input" or "textarea") && type is null or "text" or "email" or "search" or "tel" or "url" or "number" or "password")
        {
            var value = element.IsPasswordInput ? "\"REPLACE_WITH_SECRET\"" : "\"sample value\"";
            return ("Fill", value);
        }

        return ("Click", "");
    }

    private static string AdaptExpressionToPageVariable(string expression, string variableName) =>
        expression.StartsWith("Page.", StringComparison.Ordinal)
            ? variableName + expression["Page".Length..]
            : expression;

    private static string SanitizeIdentifier(string raw)
    {
        var sb = new StringBuilder();
        foreach (var c in raw)
        {
            if (char.IsLetterOrDigit(c))
            {
                sb.Append(c);
            }
            else if (sb.Length > 0 && sb[^1] != '_')
            {
                sb.Append('_');
            }
        }

        var result = sb.ToString().Trim('_');
        if (result.Length == 0)
        {
            result = "Element";
        }

        if (char.IsDigit(result[0]))
        {
            result = "_" + result;
        }

        return char.ToUpperInvariant(result[0]) + result[1..];
    }
}
