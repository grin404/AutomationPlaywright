using System.Text;
using PlaywrightElementInspector.Application.Interfaces;
using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Application.Services;

/// <summary>Builds a Page Object class from selected elements. Each member becomes an ILocator-returning property backed by its recommended candidate.</summary>
public sealed class PageObjectGenerator : IPageObjectGenerator
{
    public string Generate(string className, IReadOnlyList<PageObjectMember> members)
    {
        var sanitizedClassName = SanitizeTypeIdentifier(className);
        var usedNames = new HashSet<string>(StringComparer.Ordinal);

        var sb = new StringBuilder();
        sb.AppendLine("using Microsoft.Playwright;");
        sb.AppendLine();
        sb.AppendLine("namespace GeneratedPageObjects;");
        sb.AppendLine();
        sb.AppendLine($"public class {sanitizedClassName}");
        sb.AppendLine("{");
        sb.AppendLine("    private readonly IPage _page;");
        sb.AppendLine();
        sb.AppendLine($"    public {sanitizedClassName}(IPage page)");
        sb.AppendLine("    {");
        sb.AppendLine("        _page = page;");
        sb.AppendLine("    }");

        foreach (var member in members)
        {
            var propertyName = MakeUniquePropertyName(member.PropertyName, usedNames);
            var expression = AdaptExpressionToPageField(member.Candidate.CSharpExpression);

            sb.AppendLine();
            sb.AppendLine($"    public ILocator {propertyName} =>");
            sb.AppendLine($"        {expression};");
        }

        sb.AppendLine("}");

        return sb.ToString();
    }

    private static string MakeUniquePropertyName(string desired, HashSet<string> used)
    {
        var sanitized = SanitizeTypeIdentifier(desired);
        var candidate = sanitized;
        var suffix = 2;

        while (!used.Add(candidate))
        {
            candidate = $"{sanitized}{suffix}";
            suffix++;
        }

        return candidate;
    }

    private static string AdaptExpressionToPageField(string expression) =>
        expression.StartsWith("Page.", StringComparison.Ordinal)
            ? "_page" + expression["Page".Length..]
            : expression;

    private static string SanitizeTypeIdentifier(string raw)
    {
        var sb = new StringBuilder();
        foreach (var c in raw)
        {
            if (char.IsLetterOrDigit(c))
            {
                sb.Append(c);
            }
        }

        var result = sb.ToString();
        if (result.Length == 0)
        {
            result = "Element";
        }

        if (char.IsDigit(result[0]))
        {
            result = "_" + result;
        }

        return char.ToUpperInvariant(result[0]) + result[1..];
    }
}
