using PlaywrightElementInspector.Application.Interfaces;
using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Application.Services;

/// <summary>
/// Generates ranked Playwright locator candidates from element metadata already captured during
/// inspection. Pure logic — takes no live page dependency, so it is fully unit-testable.
/// </summary>
public sealed class LocatorGenerator : ILocatorGenerator
{
    private const int MaxTextCandidateLength = 60;

    // Roles too generic to be a useful GetByRole anchor even when present.
    private static readonly HashSet<string> NonAnchorRoles = new(StringComparer.OrdinalIgnoreCase)
    {
        "generic", "none", "presentation"
    };

    public IReadOnlyList<LocatorCandidate> GenerateCandidates(InspectedElement element, InspectorOptions options)
    {
        var candidates = new List<LocatorCandidate>();
        var prefix = FramePrefix(element.Frame);

        AddRoleCandidate(candidates, element, prefix);
        AddLabelCandidate(candidates, element, prefix);
        AddTestIdCandidate(candidates, element, prefix, options);
        AddPlaceholderCandidate(candidates, element, prefix);
        AddTextCandidate(candidates, element, prefix);
        AddCssIdCandidate(candidates, element, prefix);
        AddCssAttributeCandidate(candidates, element, prefix, options);
        AddCssClassCandidate(candidates, element, prefix);
        AddXPathCandidate(candidates, element, prefix);

        return candidates;
    }

    private static void AddRoleCandidate(List<LocatorCandidate> candidates, InspectedElement element, string prefix)
    {
        if (string.IsNullOrWhiteSpace(element.Role) || NonAnchorRoles.Contains(element.Role))
        {
            return;
        }

        var name = FirstNonEmpty(element.AccessibleName, element.Text);
        if (string.IsNullOrWhiteSpace(name))
        {
            return;
        }

        var roleEnumName = ToPascalRole(element.Role);
        var expression = $"{prefix}.GetByRole(AriaRole.{roleEnumName}, new() {{ Name = \"{Escape(name)}\" }})";

        candidates.Add(new LocatorCandidate
        {
            Strategy = LocatorStrategyType.Role,
            CSharpExpression = expression,
            RoleName = element.Role,
            MatchValue = name,
            Exact = true,
            Frame = element.Frame,
            BaselineScore = 100
        });
    }

    private static void AddLabelCandidate(List<LocatorCandidate> candidates, InspectedElement element, string prefix)
    {
        if (string.IsNullOrWhiteSpace(element.LabelText))
        {
            return;
        }

        var expression = $"{prefix}.GetByLabel(\"{Escape(element.LabelText)}\")";

        candidates.Add(new LocatorCandidate
        {
            Strategy = LocatorStrategyType.Label,
            CSharpExpression = expression,
            MatchValue = element.LabelText,
            Exact = true,
            Frame = element.Frame,
            BaselineScore = 95
        });
    }

    private static void AddTestIdCandidate(List<LocatorCandidate> candidates, InspectedElement element, string prefix, InspectorOptions options)
    {
        if (string.IsNullOrWhiteSpace(element.TestIdAttributeName) || string.IsNullOrWhiteSpace(element.TestIdValue))
        {
            return;
        }

        var isDefaultAttribute = string.Equals(element.TestIdAttributeName, "data-testid", StringComparison.OrdinalIgnoreCase);

        if (isDefaultAttribute)
        {
            candidates.Add(new LocatorCandidate
            {
                Strategy = LocatorStrategyType.TestId,
                CSharpExpression = $"{prefix}.GetByTestId(\"{Escape(element.TestIdValue)}\")",
                MatchValue = element.TestIdValue,
                AttributeName = element.TestIdAttributeName,
                Exact = true,
                Frame = element.Frame,
                BaselineScore = 90
            });
            return;
        }

        // Non-default test attribute (e.g. data-test, data-qa): Playwright's GetByTestId only reads the
        // single globally-configured attribute, so this is expressed as an attribute selector instead —
        // still scored close to TestId tier because it is clearly an intentional QA hook.
        var selector = $"[{element.TestIdAttributeName}='{Escape(element.TestIdValue)}']";
        candidates.Add(new LocatorCandidate
        {
            Strategy = LocatorStrategyType.CssAttribute,
            CSharpExpression = $"{prefix}.Locator(\"{Escape(selector)}\")",
            MatchValue = selector,
            AttributeName = element.TestIdAttributeName,
            Exact = true,
            Frame = element.Frame,
            BaselineScore = 88
        });
    }

    private static void AddPlaceholderCandidate(List<LocatorCandidate> candidates, InspectedElement element, string prefix)
    {
        if (string.IsNullOrWhiteSpace(element.Placeholder))
        {
            return;
        }

        candidates.Add(new LocatorCandidate
        {
            Strategy = LocatorStrategyType.Placeholder,
            CSharpExpression = $"{prefix}.GetByPlaceholder(\"{Escape(element.Placeholder)}\")",
            MatchValue = element.Placeholder,
            Exact = true,
            Frame = element.Frame,
            BaselineScore = 85
        });
    }

    private static void AddTextCandidate(List<LocatorCandidate> candidates, InspectedElement element, string prefix)
    {
        var text = element.Text?.Trim();
        if (string.IsNullOrWhiteSpace(text) || text.Length > MaxTextCandidateLength)
        {
            return;
        }

        candidates.Add(new LocatorCandidate
        {
            Strategy = LocatorStrategyType.Text,
            CSharpExpression = $"{prefix}.GetByText(\"{Escape(text)}\", new() {{ Exact = true }})",
            MatchValue = text,
            Exact = true,
            Frame = element.Frame,
            BaselineScore = 75
        });
    }

    private static void AddCssIdCandidate(List<LocatorCandidate> candidates, InspectedElement element, string prefix)
    {
        if (string.IsNullOrWhiteSpace(element.Id))
        {
            return;
        }

        var selector = $"#{CssEscapeIdentifier(element.Id)}";
        candidates.Add(new LocatorCandidate
        {
            Strategy = LocatorStrategyType.CssId,
            CSharpExpression = $"{prefix}.Locator(\"{Escape(selector)}\")",
            MatchValue = selector,
            AttributeName = "id",
            Frame = element.Frame,
            BaselineScore = 70
        });
    }

    private static void AddCssAttributeCandidate(List<LocatorCandidate> candidates, InspectedElement element, string prefix, InspectorOptions options)
    {
        // Skip if this same attribute was already captured as a test-id candidate above.
        if (!string.IsNullOrWhiteSpace(element.TestIdAttributeName))
        {
            return;
        }

        (string Name, string? Value)[] preferenceOrder =
        {
            ("name", element.Name),
            ("aria-label", element.AriaLabel),
            ("title", element.Title)
        };

        foreach (var (attrName, attrValue) in preferenceOrder)
        {
            if (string.IsNullOrWhiteSpace(attrValue))
            {
                continue;
            }

            var selector = $"[{attrName}='{Escape(attrValue)}']";
            candidates.Add(new LocatorCandidate
            {
                Strategy = LocatorStrategyType.CssAttribute,
                CSharpExpression = $"{prefix}.Locator(\"{Escape(selector)}\")",
                MatchValue = selector,
                AttributeName = attrName,
                Frame = element.Frame,
                BaselineScore = 60
            });
            return; // one attribute candidate is enough; scoring/validation decide if it's good
        }
    }

    private static void AddCssClassCandidate(List<LocatorCandidate> candidates, InspectedElement element, string prefix)
    {
        if (string.IsNullOrWhiteSpace(element.ClassAttribute))
        {
            return;
        }

        var classes = element.ClassAttribute.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (classes.Length == 0)
        {
            return;
        }

        var take = classes.Take(2);
        var selector = element.Tag + string.Concat(take.Select(c => $".{CssEscapeIdentifier(c)}"));

        candidates.Add(new LocatorCandidate
        {
            Strategy = LocatorStrategyType.CssClass,
            CSharpExpression = $"{prefix}.Locator(\"{Escape(selector)}\")",
            MatchValue = selector,
            AttributeName = "class",
            Frame = element.Frame,
            BaselineScore = 40
        });
    }

    private static void AddXPathCandidate(List<LocatorCandidate> candidates, InspectedElement element, string prefix)
    {
        var xpath = element.AbsoluteXPath;
        candidates.Add(new LocatorCandidate
        {
            Strategy = LocatorStrategyType.XPath,
            CSharpExpression = $"{prefix}.Locator(\"xpath={Escape(xpath)}\")",
            MatchValue = xpath,
            Frame = element.Frame,
            BaselineScore = 20
        });
    }

    private static string FramePrefix(FrameContext frame)
    {
        if (frame.IsMainFrame)
        {
            return "Page";
        }

        var hint = frame.SelectorHint ?? (frame.Name is not null ? $"iframe[name='{Escape(frame.Name)}']" : "iframe");
        return $"Page.FrameLocator(\"{Escape(hint)}\")";
    }

    private static string? FirstNonEmpty(params string?[] values) =>
        values.FirstOrDefault(v => !string.IsNullOrWhiteSpace(v));

    private static string ToPascalRole(string role)
    {
        if (role.Length == 0)
        {
            return role;
        }

        return char.ToUpperInvariant(role[0]) + role[1..].ToLowerInvariant();
    }

    private static string Escape(string value) =>
        value.Replace("\\", "\\\\").Replace("\"", "\\\"");

    private static string CssEscapeIdentifier(string value)
    {
        // Minimal CSS identifier escaping for characters that aren't valid unescaped in a selector token.
        var chars = value.Select(c => char.IsLetterOrDigit(c) || c is '-' or '_' ? c.ToString() : $"\\{c}");
        return string.Concat(chars);
    }
}
