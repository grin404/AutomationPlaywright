namespace PlaywrightElementInspector.Application;

/// <summary>Raised for expected, user-facing failure conditions (missing browser, navigation failure, ...).</summary>
public sealed class PlaywrightElementInspectorException : Exception
{
    public PlaywrightElementInspectorException(string message) : base(message)
    {
    }

    public PlaywrightElementInspectorException(string message, Exception innerException) : base(message, innerException)
    {
    }
}
