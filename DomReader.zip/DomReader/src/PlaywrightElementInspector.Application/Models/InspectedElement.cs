namespace PlaywrightElementInspector.Application.Models;

/// <summary>
/// Snapshot of one DOM node captured during inspection. Never carries the live value of a
/// password input — <see cref="IsPasswordInput"/> is the only signal exposed for such fields.
/// </summary>
public sealed record InspectedElement
{
    /// <summary>Stable-for-session identifier (frame path + ordinal DOM path). Not a live handle.</summary>
    public required string InternalId { get; init; }

    public required FrameContext Frame { get; init; }

    public required string Tag { get; init; }

    public string? Role { get; init; }

    public string? AccessibleName { get; init; }

    /// <summary>Trimmed, length-capped visible text content of the element itself (not descendants' full text).</summary>
    public string? Text { get; init; }

    public string? Id { get; init; }

    public string? Name { get; init; }

    public string? ClassAttribute { get; init; }

    public string? InputType { get; init; }

    public string? Placeholder { get; init; }

    public string? Title { get; init; }

    public string? AriaLabel { get; init; }

    public string? AriaLabelledBy { get; init; }

    public string? TestIdAttributeName { get; init; }

    public string? TestIdValue { get; init; }

    public string? LabelText { get; init; }

    public required IReadOnlyDictionary<string, string> Attributes { get; init; }

    public bool IsVisible { get; init; }

    public bool IsEnabled { get; init; }

    public bool IsPasswordInput { get; init; }

    public BoundingBox? BoundingBox { get; init; }

    /// <summary>Absolute structural XPath, used only as the last-resort candidate.</summary>
    public required string AbsoluteXPath { get; init; }

    public int DomDepth { get; init; }

    public string? ParentId { get; init; }

    public IReadOnlyList<string> ChildIds { get; init; } = Array.Empty<string>();

    public bool IsInShadowDom { get; init; }

    public string? ShadowHostDescription { get; init; }

    public required ElementCategory Category { get; init; }

    /// <summary>1-based index of this element among its same-tag siblings; used by fragility heuristics.</summary>
    public int SiblingIndexOfSameTag { get; init; } = 1;

    public int SiblingCountOfSameTag { get; init; } = 1;
}
