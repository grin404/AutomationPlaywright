namespace PlaywrightElementInspector.Application.Models;

public sealed record InspectorOptions
{
    public PageReadyStrategy WaitStrategy { get; init; } = PageReadyStrategy.NetworkIdle;

    public int FixedDelayMs { get; init; } = 1000;

    public int NetworkIdleTimeoutMs { get; init; } = 8000;

    public bool HighlightElements { get; init; } = true;

    public bool IncludeLowValueElements { get; init; } = false;

    /// <summary>Attribute names checked, in order, when looking for a test-id style hook.</summary>
    public IReadOnlyList<string> TestIdAttributes { get; init; } =
        new[] { "data-testid", "data-test", "data-qa" };
}
