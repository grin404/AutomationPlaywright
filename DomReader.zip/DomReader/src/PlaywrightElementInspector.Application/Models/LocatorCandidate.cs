namespace PlaywrightElementInspector.Application.Models;

/// <summary>
/// One generated locator candidate. <see cref="RoleName"/>/<see cref="MatchValue"/>/<see cref="Exact"/>
/// carry enough structured data for the Infrastructure layer to build a real Playwright ILocator without
/// re-parsing the generated C# text; <see cref="CSharpExpression"/> is what gets shown/copied to the user.
/// </summary>
public sealed record LocatorCandidate
{
    public required LocatorStrategyType Strategy { get; init; }

    /// <summary>Human-facing generated C# expression, e.g. Page.GetByRole(AriaRole.Button, new() { Name = "Login" }).</summary>
    public required string CSharpExpression { get; init; }

    /// <summary>For Role strategy: the ARIA role name (e.g. "button"). Null for other strategies.</summary>
    public string? RoleName { get; init; }

    /// <summary>Primary match value used by the strategy (accessible name, label text, test-id value, placeholder text, visible text, attribute value, CSS selector, or XPath expression).</summary>
    public required string MatchValue { get; init; }

    /// <summary>Attribute name backing CssAttribute/TestId strategies (e.g. "data-testid", "name").</summary>
    public string? AttributeName { get; init; }

    public bool Exact { get; init; } = true;

    /// <summary>Frame this candidate must be scoped through; null/main-frame means plain Page.*.</summary>
    public required FrameContext Frame { get; init; }

    public int BaselineScore { get; init; }

    public int Score { get; set; }

    public RecommendationLevel Recommendation { get; set; } = RecommendationLevel.Low;

    public List<string> ScoreReasons { get; init; } = new();

    public LocatorValidationResult? Validation { get; set; }
}
