namespace PlaywrightElementInspector.Application.Models;

/// <summary>Identifies which frame an element lives in. Path is the chain of frame names/urls from the main frame.</summary>
public sealed record FrameContext(
    bool IsMainFrame,
    string? Name,
    string Url,
    IReadOnlyList<string> FramePath,
    string? SelectorHint);

public static class FrameContextExtensions
{
    public static FrameContext MainFrame(string url) =>
        new(IsMainFrame: true, Name: null, Url: url, FramePath: Array.Empty<string>(), SelectorHint: null);
}
