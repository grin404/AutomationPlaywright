namespace PlaywrightElementInspector.Application.Models;

public enum ElementCategory
{
    Interactive,
    Semantic,
    Structural,
    LowValue
}
