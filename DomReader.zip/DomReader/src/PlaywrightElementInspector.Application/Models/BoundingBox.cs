namespace PlaywrightElementInspector.Application.Models;

public sealed record BoundingBox(double X, double Y, double Width, double Height);
