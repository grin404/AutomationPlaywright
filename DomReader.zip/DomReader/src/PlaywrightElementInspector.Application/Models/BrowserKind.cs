namespace PlaywrightElementInspector.Application.Models;

public enum BrowserKind
{
    Chromium,
    Firefox,
    WebKit
}
