namespace PlaywrightElementInspector.Application.Models;

public enum RecommendationLevel
{
    Avoid,
    Low,
    Medium,
    High
}
