namespace PlaywrightElementInspector.Application.Models;

/// <summary>One selected element destined to become a property (and optionally an action) on a generated Page Object.</summary>
public sealed record PageObjectMember(
    string PropertyName,
    InspectedElement Element,
    LocatorCandidate Candidate);

public sealed record ExportedElementRecord(
    string InternalId,
    string Tag,
    string? Role,
    string? AccessibleName,
    string FrameUrl,
    bool IsVisible,
    bool IsEnabled,
    IReadOnlyList<ExportedCandidateRecord> Candidates);

public sealed record ExportedCandidateRecord(
    string Strategy,
    string CSharpExpression,
    int Score,
    string Recommendation,
    int MatchCount,
    bool TargetMatched,
    IReadOnlyList<string> ScoreReasons);
