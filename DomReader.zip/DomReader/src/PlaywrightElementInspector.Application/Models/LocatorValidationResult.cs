namespace PlaywrightElementInspector.Application.Models;

public sealed record LocatorValidationResult
{
    public required bool Resolved { get; init; }

    public int MatchCount { get; init; }

    public bool TargetMatched { get; init; }

    public bool? IsVisible { get; init; }

    public bool? IsEnabled { get; init; }

    /// <summary>True when the original element could not be re-located (removed/replaced since inspection).</summary>
    public bool IsStale { get; init; }

    public string? Error { get; init; }
}
