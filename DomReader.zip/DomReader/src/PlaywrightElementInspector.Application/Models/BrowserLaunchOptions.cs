namespace PlaywrightElementInspector.Application.Models;

public sealed record BrowserLaunchOptions
{
    public BrowserKind Browser { get; init; } = BrowserKind.Chromium;

    public bool Headless { get; init; } = false;

    public string? ExecutablePath { get; init; }

    /// <summary>User-writable folder browser binaries are installed into/read from. Never a system path.</summary>
    public required string BrowserStoragePath { get; init; }

    public int ViewportWidth { get; init; } = 1280;

    public int ViewportHeight { get; init; } = 720;

    /// <summary>When set, launches a persistent context rooted at this user-writable profile folder so logins survive across runs.</summary>
    public string? PersistentProfilePath { get; init; }
}
