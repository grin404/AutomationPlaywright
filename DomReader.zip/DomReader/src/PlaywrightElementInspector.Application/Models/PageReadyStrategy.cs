namespace PlaywrightElementInspector.Application.Models;

public enum PageReadyStrategy
{
    DomContentLoaded,
    NetworkIdle,
    FixedDelay
}
