namespace PlaywrightElementInspector.Application.Models;

/// <summary>Ordered roughly by default priority; actual ranking is score-driven, not enum order.</summary>
public enum LocatorStrategyType
{
    Role,
    Label,
    TestId,
    Placeholder,
    Text,
    CssId,
    CssAttribute,
    CssClass,
    XPath
}
