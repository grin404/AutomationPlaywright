namespace PlaywrightElementInspector.Application.Models;

public sealed class AppConfig
{
    public BrowserConfigSection Browser { get; set; } = new();

    public InspectorConfigSection Inspector { get; set; } = new();
}

public sealed class BrowserConfigSection
{
    public string DefaultBrowser { get; set; } = "Chromium";

    public bool Headless { get; set; } = false;

    public string ExecutablePath { get; set; } = "";

    public string BrowserStoragePath { get; set; } = "./playwright-browsers";

    public int ViewportWidth { get; set; } = 1280;

    public int ViewportHeight { get; set; } = 720;
}

public sealed class InspectorConfigSection
{
    public string DefaultWaitStrategy { get; set; } = "NetworkIdle";

    public bool HighlightElements { get; set; } = true;
}
