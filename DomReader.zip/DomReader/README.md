# Playwright Element Inspector

A portable Windows desktop tool for QA engineers: point it at a URL, inspect the rendered DOM, and get
ranked, live-validated Microsoft.Playwright (.NET) locator candidates — plus copy-paste C# snippets, NUnit
tests, and generated Page Object classes. Runs entirely locally, headed by default, no admin rights ever
required. See [`DESIGN.md`](DESIGN.md) for the full architecture/design rationale.

## Prerequisites

- Windows 10/11
- [.NET 8 SDK](https://dotnet.microsoft.com/download) (or newer) for development/build
- No admin rights needed for any step below

## Solution layout

```
PlaywrightElementInspector.sln
├── src/
│   ├── PlaywrightElementInspector.Application/    # models, interfaces, pure-logic services (locator gen/scoring/codegen) — no Playwright dependency
│   ├── PlaywrightElementInspector.Infrastructure/ # Playwright driver, browser install/launch, DOM walker, config, logging
│   └── PlaywrightElementInspector.UI/             # WPF app (MVVM, CommunityToolkit.Mvvm)
└── tests/
    ├── PlaywrightElementInspector.Tests.Unit/         # no browser required
    ├── PlaywrightElementInspector.Tests.Integration/  # headless Chromium against tests/Fixtures/*.html
    └── Fixtures/                                      # local HTML fixtures (no internet access needed)
```

## Development

```
dotnet restore
dotnet build
dotnet run --project src/PlaywrightElementInspector.UI
```

On first run the app writes a default `appsettings.json` next to the executable (see **Configuration**
below) and creates `%LOCALAPPDATA%\PlaywrightElementInspector\` for logs and browser profiles.

## Testing

```
dotnet test tests/PlaywrightElementInspector.Tests.Unit
dotnet test tests/PlaywrightElementInspector.Tests.Integration
```

- **Unit tests** cover locator generation, the scoring/fragility-detection algorithm, code generation, and
  export — all pure logic, no browser launched.
- **Integration tests** launch headless Chromium (via this app's own `IBrowserManager`/`IDomInspector`/
  `ILocatorValidator`) against the local HTML fixtures in `tests/Fixtures/`, served over
  `http://127.0.0.1` by a throwaway in-process listener — no external network access is used, so the suite
  is CI-safe and deterministic.
- Integration tests need Chromium installed once beforehand (see **Browser Setup**); they honor
  `PLAYWRIGHT_BROWSERS_PATH` if set, otherwise fall back to Playwright's default user cache
  (`%LOCALAPPDATA%\ms-playwright`).

## Browser Setup (no admin required)

The app never assumes browsers are globally installed. It detects binaries under the configured
`BrowserStoragePath` (default `./playwright-browsers` next to the executable, or
`%LOCALAPPDATA%\PlaywrightElementInspector\playwright-browsers` if that folder isn't writable) and offers
an **Install Browser** button when missing, which downloads into that same user-writable folder.

To install ahead of time for development/tests, from a built project's output folder:

```
pwsh bin/Debug/net8.0/playwright.ps1 install chromium firefox webkit
```

(or `powershell` in place of `pwsh` on stock Windows). This uses Playwright's own installer — no
elevation, no system-wide registration.

## Publishing (portable deployment)

Self-contained, single-folder (recommended default — maximum portability):

```
dotnet publish src/PlaywrightElementInspector.UI -c Release -r win-x64 --self-contained true
```

Framework-dependent (smaller output, requires the .NET 8 desktop runtime already installed on the target
machine):

```
dotnet publish src/PlaywrightElementInspector.UI -c Release -r win-x64 --self-contained false
```

Single-file (optional, one `.exe` instead of a folder of DLLs):

```
dotnet publish src/PlaywrightElementInspector.UI -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
```

Single-file tradeoffs: slightly slower first launch (self-extracts native/managed assets to a temp
directory each run), and it does not reduce the Playwright browser binaries themselves — those are always
downloaded separately into `BrowserStoragePath` regardless of publish mode. Prefer the plain self-contained
folder unless a single executable is specifically required.

## Portable Usage

Copy the published output folder anywhere user-writable — Desktop, Downloads, a USB drive, a network
share, a custom folder — and run the `.exe` directly. The app:

- writes its config (`appsettings.json`) beside the executable, falling back silently to in-memory
  defaults if that location isn't writable;
- writes logs and browser profiles under `%LOCALAPPDATA%\PlaywrightElementInspector\`;
- stores/reads Playwright browser binaries under the configured `BrowserStoragePath`.

No installer, no registry writes, no Program Files placement, no elevation prompt at any point.

## Configuration

`appsettings.json` (created with defaults on first run, editable anytime):

```json
{
  "Browser": {
    "DefaultBrowser": "Chromium",
    "Headless": false,
    "ExecutablePath": "",
    "BrowserStoragePath": "./playwright-browsers",
    "ViewportWidth": 1280,
    "ViewportHeight": 720
  },
  "Inspector": {
    "DefaultWaitStrategy": "NetworkIdle",
    "HighlightElements": true
  }
}
```

## No-Admin Design

- Browser binaries install into a user-writable folder, never the machine-wide Program Files location.
- Config, logs, and browser profiles live under the executable's own folder or `%LOCALAPPDATA%`.
- No Windows service, no registry writes, no global environment variables.
- Self-contained publish means no separate .NET runtime installer is required on the target machine.

## Security & Privacy

- All processing is local: no telemetry, no external AI calls, nothing about the inspected page or its
  content is ever transmitted anywhere.
- Password input values are never read, stored, logged, or exported — the DOM inspector doesn't capture
  the `value` attribute for any element, and password fields are only ever flagged via `IsPasswordInput`.
- The structured file logger redacts any `password=`/`token=`/`cookie=`/`authorization=`-shaped text as a
  defense-in-depth measure, on top of the app never intentionally logging such data.
- The app does not attempt to bypass authentication, CAPTCHA, MFA, or any other site security control —
  the expected flow is: load the page, authenticate manually in the visible browser window, then click
  **Inspect Page**.

## Limitations

- **Closed shadow roots** are fundamentally unobservable via Playwright/CDP; only open shadow roots are
  traversed.
- **Cross-origin iframes** that refuse script access are skipped with a logged notice rather than crashing
  the run.
- **XPath does not pierce shadow DOM** (a Playwright/browser limitation, not this app's) — internal
  re-location for validation/highlighting prefers an id-based CSS selector (which does pierce shadow
  roots) when the element has an id, falling back to XPath only when it doesn't.
- **Sites that actively block automation** (bot detection, aggressive CSP, etc.) may prevent navigation or
  inspection entirely; this tool does not attempt to evade such protections.
- **NetworkIdle** can time out on pages with persistent background traffic (polling, websockets); the app
  falls back to whatever DOM state is available after the configured timeout rather than hanging.
- Frame re-identification after a **reload** relies on URL/name matching; a frame whose URL changes on
  reload may not re-resolve for validation until the page is re-inspected.
