# Playwright Element Inspector — Technical Design

## Architecture

Clean layered design, UI decoupled from engine:

```
PlaywrightElementInspector.sln
├── src/
│   ├── PlaywrightElementInspector.Application/   # domain models, interfaces, services (no UI, no Playwright types leak out via IPage where avoidable)
│   ├── PlaywrightElementInspector.Infrastructure/ # Playwright driver, browser mgmt, config, logging
│   └── PlaywrightElementInspector.UI/             # WPF app (MVVM)
└── tests/
    ├── PlaywrightElementInspector.Tests.Unit/
    ├── PlaywrightElementInspector.Tests.Integration/
    └── Fixtures/  (login.html, dynamic.html, iframe.html, shadow-dom.html, accessibility.html)
```

Application layer defines interfaces (`IBrowserSession`, `IDomInspector`, `ILocatorGenerator`, `ILocatorValidator`, `IPageObjectGenerator`, `IExportService`). Infrastructure implements them against Microsoft.Playwright. UI only depends on Application interfaces + DI container, never touches `IPage` directly — keeps engine testable/reusable outside WPF.

## UI Framework: WPF

Chosen over WinUI/WinForms/Avalonia because: mature MVVM/data-binding fits tree+detail+candidate-list layout well, ships fine with `dotnet publish -r win-x64 --self-contained`, no admin/MSIX install needed (unlike WinUI3 which often wants packaging), better tooling maturity than Avalonia for this scope, richer UI composition than WinForms for the panel-heavy layout. Tradeoff: Windows-only — acceptable, spec targets Windows portable app only.

## Portable Deployment

- `dotnet publish -c Release -r win-x64 --self-contained true` — primary distribution mode. Fully portable, no .NET runtime install needed, runs from any writable folder (Desktop/Downloads/USB/network).
- Framework-dependent build documented as smaller-footprint alternative, requires .NET 8 runtime present.
- `PublishSingleFile=true` optional single-exe convenience. Tradeoff: slower first-run cold start (self-extraction to temp), larger single artifact, and native deps (some Playwright-adjacent components) don't always single-file well — document as opt-in with caveat, not default.
- No install into Program Files, no registry writes, no admin elevation anywhere in app logic.

## Playwright Browser Management

- `BrowserStoragePath` config (default `./playwright-browsers` relative to exe, resolved to absolute writable path e.g. next to exe or `%LOCALAPPDATA%\PlaywrightElementInspector\browsers` if exe dir not writable).
- Set `PLAYWRIGHT_BROWSERS_PATH` env var to that folder before invoking Playwright driver — keeps binaries local/portable, not in default global cache.
- On startup: probe if required browser executable exists (`BrowserType.ExecutablePathAsync` style check / folder probe). If missing, show "Install Browser" action that runs Playwright's install CLI (`Microsoft.Playwright.Program.Main(["install", "chromium"])`) targeting the configured folder — all user-writable, no admin.
- Support Chromium/Firefox/WebKit selection; clear error UI if binaries absent or launch fails.

## DOM Inspection Approach

- After navigation, wait per configured `PageReadyStrategy` (DOMContentLoaded / NetworkIdle / fixed delay), default NetworkIdle with timeout fallback (SPA apps may never go fully idle — fallback to DOMContentLoaded + short settle delay if NetworkIdle times out).
- Snapshot rendered DOM via `Page.EvaluateAsync` walking `document` (including open shadow roots, and each accessible frame's `document`), collecting only "useful" nodes: interactive tags (button/input/textarea/select/option/a/[role]), semantic/labeled elements, elements with id/name/test attributes. Structural-only wrappers (bare div/span with no attrs, no text, no role) excluded from default tree, filterable back in via "show all".
- Each collected node gets a stable-for-session internal handle (frame path + generated ordinal path) so it can be re-located for validation/highlight without keeping a live `IElementHandle` reference the whole time (avoids detachment crashes) — re-query via generated locator when acting on it.
- Frames: recurse `Page.Frames`, tag each element with owning frame's path (name/url chain); cross-origin frames that throw on access are skipped with a logged, user-visible notice, not a crash.
- Shadow DOM: traversal uses `element.shadowRoot` where open; closed roots are undetectable (documented limitation) — flagged in UI as "shadow root (closed, not inspectable)" when a custom element with no accessible shadowRoot content is suspected.

## Locator Generation Algorithm

For each element, attempt candidate generation in this priority (skip strategies that don't apply):
1. `GetByRole` (role + accessible name computed via ARIA + implicit role mapping)
2. `GetByLabel` (via `<label for>`/wrapping label/aria-labelledby)
3. `GetByTestId` (configurable attribute list: data-testid, data-test, data-qa)
4. `GetByPlaceholder`
5. `GetByText` (exact, only if text short/stable-looking)
6. Stable CSS via `#id` (only if id doesn't look generated)
7. Stable CSS via custom attribute (name, aria-label, etc.)
8. CSS class combinator (last resort before XPath)
9. XPath absolute/relative path (final fallback)

Each candidate carries: strategy type, generated C# expression string, and raw selector for validation. Frame-scoped elements generate `FrameLocator(...)`-prefixed code, not bare `Page.Locator`.

## Locator Scoring Algorithm

Baseline weights (spec's starting points): Role 100, Label 95, TestId 90, Placeholder 85, Text 75, CSS-ID 70, custom-attr 60, CSS-class 40, XPath 20.

Adjustments applied after baseline:
- **Match count**: exactly 1 → no penalty; 2-3 → -15; 4+ → -35 (locator ambiguous, unreliable in practice even if target present).
- **Target-not-among-matches**: hard fail, score → 0, marked invalid regardless of strategy.
- **Generated-ID heuristic** (regex: trailing long digit runs, hash-like segments `css-1x7abc9`, framework auto-ids `ctl00_...`, `ember\d+`, guid-like): -30, tag reason "looks auto-generated/unstable".
- **Selector structural fragility** (nth-child chains, deep absolute XPath >4 levels, index-based sibling selection): -25, tag "position-dependent, breaks on DOM reorder".
- **Length/depth penalty**: long CSS/XPath chains (>3 combinators) -10.
- **Visibility/enabled state**: not visible or disabled at inspection time → informational flag, small -5 (may be legitimately hidden-until-interaction, not auto-fail).
- Score clamped [0,100]; Recommendation band: ≥85 High, 60-84 Medium, 30-59 Low, <30 Avoid (still shown, never hidden, since spec says don't auto-reject only option).
- Highest-scoring *valid* (target-matched) candidate becomes the recommended one shown first.

## Locator Validation Strategy

For each candidate, against live `IPage`/`IFrame`:
1. Build actual `ILocator` from the same code Playwright generation used (not a re-parsed string) — guarantees generated snippet == what was validated.
2. `CountAsync()` → match count.
3. Compare each match's element identity to originally selected element via a DOM-side marker: on selection, stamp target with a temp `data-pw-inspector-id` attribute (removed on deselect/highlight-off) — cheap, reversible, not part of generated locator output.
4. `IsVisibleAsync()`/`IsEnabledAsync()` on first match (best-effort, swallow exceptions if detached — mark "stale, re-validate").
5. Feed match count + target-matched + visibility/enabled into scoring adjustments above → confidence %.
6. Detached-element handling: if original element's marker attribute no longer found anywhere, mark element "detached" in UI, offer "Refresh DOM" instead of crashing.

## Authentication / Session Handling

- Headed mode default; user manually logs in in the visible browser window before clicking "Inspect".
- Optional persistent context: `BrowserType.LaunchPersistentContextAsync` pointed at a user-writable profile dir (configurable, e.g. `%LOCALAPPDATA%\PlaywrightElementInspector\profiles\<name>`), so repeated runs can reuse a logged-in session. Never exported, never logged.
- No credential capture, no auth bypass logic anywhere.

## Export / Code Generation

- Locator-only snippet, full C# action snippet, NUnit test snippet, Page Object class — all generated from same candidate model, templated via plain string builders (no heavy templating engine needed at this scope).
- JSON/CSV export of element+candidate+score+validation data. Password-type inputs: value field always omitted/redacted (`***REDACTED***`) at model level, not just at export — so it can never leak via any surface (UI, log, export).

## Testing Strategy

- Unit tests: locator generation given synthetic DOM-node models (no browser), scoring algorithm given synthetic candidate/match data, fragile-selector regex detectors, PageObject/code-gen string output.
- Integration tests: NUnit + Playwright launched headless against local static HTML fixtures (`tests/Fixtures/*.html` loaded via `file://` or a tiny local `HttpListener`) — covers real DOM inspection, real locator validation (match count, target identity, visibility), iframe fixture, shadow-dom fixture, dynamic (JS-injected) fixture, accessibility fixture (aria roles/labels), duplicate-name/duplicate-label edge cases.
- No external network dependency in tests — CI-safe.

## Security Considerations

- Zero network egress beyond the user-directed navigation itself: no telemetry, no external AI calls.
- Secrets never logged: password inputs redacted at model level; structured logger has a redaction filter for common secret-looking header/field names as defense in depth.
- Logs/config/profiles all under `%LOCALAPPDATA%\PlaywrightElementInspector\`, no admin paths.

## Risks / Limitations

- NetworkIdle default can hang on chatty SPAs (websockets/polling) — mitigated with timeout+fallback, user-configurable.
- Closed shadow roots: fundamentally unobservable via Playwright/CDP — documented, not solvable.
- Cross-origin iframe restrictions: some frames may refuse content script access — skipped gracefully.
- Single-file publish + Playwright's own node-driver-less .NET impl: should work but adds cold-start cost; documented as opt-in.
- CAPTCHA/MFA/bot-detection sites: tool does not attempt bypass; user handles manually in headed browser, by design.

## Build Order (incremental)

1. Solution scaffold + Application interfaces/models + Infrastructure Playwright driver skeleton + DI wiring.
2. Browser management (detect/install) + basic navigation.
3. DOM inspection (main frame first, then frames, then shadow DOM).
4. Locator generation + scoring (unit-testable without browser).
5. Locator validation against live page.
6. WPF UI: URL bar, browser launch, element tree, detail panel, candidate list, highlight.
7. Code-gen: locator/action/NUnit/PageObject snippets + copy-to-clipboard.
8. Export JSON/CSV.
9. Config + logging plumbing.
10. Fixtures + full NUnit suite (unit + integration).
11. README + senior-level self code-review pass, fix findings.
