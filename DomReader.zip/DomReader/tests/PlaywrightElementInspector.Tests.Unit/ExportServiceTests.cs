using PlaywrightElementInspector.Application.Models;
using PlaywrightElementInspector.Application.Services;
using PlaywrightElementInspector.Tests.Unit.TestHelpers;

namespace PlaywrightElementInspector.Tests.Unit;

[TestFixture]
public class ExportServiceTests
{
    private ExportService _service = null!;

    [SetUp]
    public void SetUp() => _service = new ExportService();

    private static LocatorCandidate Candidate() => new()
    {
        Strategy = LocatorStrategyType.Role,
        CSharpExpression = "Page.GetByRole(AriaRole.Button, new() { Name = \"Login\" })",
        MatchValue = "Login",
        Frame = FrameContextExtensions.MainFrame("https://example.test/"),
        BaselineScore = 100,
        Score = 100,
        Recommendation = RecommendationLevel.High
    };

    [Test]
    public void ToJson_IncludesElementAndCandidateData()
    {
        var element = ElementFactory.Create();
        var candidates = new Dictionary<string, IReadOnlyList<LocatorCandidate>>
        {
            [element.InternalId] = new List<LocatorCandidate> { Candidate() }
        };

        var json = _service.ToJson(new[] { element }, candidates);

        Assert.That(json, Does.Contain("\"Score\": 100"));
        Assert.That(json, Does.Contain("GetByRole"));
    }

    [Test]
    public void ToJson_NeverIncludesPasswordValues()
    {
        var element = ElementFactory.Create(tag: "input", inputType: "password", isPasswordInput: true);
        var candidates = new Dictionary<string, IReadOnlyList<LocatorCandidate>>();

        var json = _service.ToJson(new[] { element }, candidates);

        Assert.That(json, Does.Not.Contain("\"Value\""));
        Assert.That(json, Does.Not.Contain("password123"));
    }

    [Test]
    public void ToCsv_ProducesHeaderAndOneRowPerCandidate()
    {
        var element = ElementFactory.Create();
        var candidates = new Dictionary<string, IReadOnlyList<LocatorCandidate>>
        {
            [element.InternalId] = new List<LocatorCandidate> { Candidate() }
        };

        var csv = _service.ToCsv(new[] { element }, candidates);
        var lines = csv.Split(Environment.NewLine, StringSplitOptions.RemoveEmptyEntries);

        Assert.That(lines[0], Does.StartWith("ElementId,Tag,Role"));
        Assert.That(lines.Length, Is.EqualTo(2));
    }

    [Test]
    public void ToCsv_ElementWithNoCandidates_StillProducesOneRow()
    {
        var element = ElementFactory.Create();
        var candidates = new Dictionary<string, IReadOnlyList<LocatorCandidate>>();

        var csv = _service.ToCsv(new[] { element }, candidates);
        var lines = csv.Split(Environment.NewLine, StringSplitOptions.RemoveEmptyEntries);

        Assert.That(lines.Length, Is.EqualTo(2));
    }
}
