using PlaywrightElementInspector.Application.Models;

namespace PlaywrightElementInspector.Tests.Unit.TestHelpers;

/// <summary>Builds synthetic InspectedElement instances for unit tests — no browser required.</summary>
internal static class ElementFactory
{
    public static InspectedElement Create(
        string tag = "button",
        string? role = "button",
        string? accessibleName = "Login",
        string? text = null,
        string? id = null,
        string? name = null,
        string? classAttribute = null,
        string? inputType = null,
        string? placeholder = null,
        string? title = null,
        string? ariaLabel = null,
        string? labelText = null,
        string? testIdAttributeName = null,
        string? testIdValue = null,
        bool isVisible = true,
        bool isEnabled = true,
        bool isPasswordInput = false,
        string absoluteXPath = "/html/body[1]/button[1]",
        FrameContext? frame = null,
        ElementCategory category = ElementCategory.Interactive,
        string internalId = "0:0")
    {
        return new InspectedElement
        {
            InternalId = internalId,
            Frame = frame ?? FrameContextExtensions.MainFrame("https://example.test/"),
            Tag = tag,
            Role = role,
            AccessibleName = accessibleName,
            Text = text,
            Id = id,
            Name = name,
            ClassAttribute = classAttribute,
            InputType = inputType,
            Placeholder = placeholder,
            Title = title,
            AriaLabel = ariaLabel,
            LabelText = labelText,
            TestIdAttributeName = testIdAttributeName,
            TestIdValue = testIdValue,
            Attributes = new Dictionary<string, string>(),
            IsVisible = isVisible,
            IsEnabled = isEnabled,
            IsPasswordInput = isPasswordInput,
            AbsoluteXPath = absoluteXPath,
            Category = category
        };
    }
}
