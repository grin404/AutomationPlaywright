using PlaywrightElementInspector.Application.Models;
using PlaywrightElementInspector.Application.Services;
using PlaywrightElementInspector.Tests.Unit.TestHelpers;

namespace PlaywrightElementInspector.Tests.Unit;

[TestFixture]
public class PageObjectGeneratorTests
{
    private PageObjectGenerator _generator = null!;

    [SetUp]
    public void SetUp() => _generator = new PageObjectGenerator();

    private static LocatorCandidate Candidate(string expression) => new()
    {
        Strategy = LocatorStrategyType.Role,
        CSharpExpression = expression,
        MatchValue = "x",
        Frame = FrameContextExtensions.MainFrame("https://example.test/"),
        BaselineScore = 100,
        Score = 100
    };

    [Test]
    public void Generate_ProducesValidClassNameAndPageField()
    {
        var member = new PageObjectMember("Username", ElementFactory.Create(), Candidate("Page.GetByLabel(\"Username\")"));
        var code = _generator.Generate("Login Page!", new[] { member });

        Assert.That(code, Does.Contain("public class LoginPage"));
        Assert.That(code, Does.Contain("private readonly IPage _page;"));
        Assert.That(code, Does.Contain("public LoginPage(IPage page)"));
    }

    [Test]
    public void Generate_MemberExpression_UsesPageFieldNotPageProperty()
    {
        var member = new PageObjectMember("LoginButton", ElementFactory.Create(), Candidate("Page.GetByRole(AriaRole.Button, new() { Name = \"Login\" })"));
        var code = _generator.Generate("LoginPage", new[] { member });

        Assert.That(code, Does.Contain("_page.GetByRole(AriaRole.Button, new() { Name = \"Login\" })"));
    }

    [Test]
    public void Generate_DuplicatePropertyNames_AreDisambiguated()
    {
        var member1 = new PageObjectMember("Field", ElementFactory.Create(internalId: "0:1"), Candidate("Page.GetByLabel(\"A\")"));
        var member2 = new PageObjectMember("Field", ElementFactory.Create(internalId: "0:2"), Candidate("Page.GetByLabel(\"B\")"));

        var code = _generator.Generate("MyPage", new[] { member1, member2 });

        Assert.That(code, Does.Contain("public ILocator Field =>"));
        Assert.That(code, Does.Contain("public ILocator Field2 =>"));
    }
}
