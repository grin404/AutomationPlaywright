using PlaywrightElementInspector.Application.Models;
using PlaywrightElementInspector.Application.Services;
using PlaywrightElementInspector.Tests.Unit.TestHelpers;

namespace PlaywrightElementInspector.Tests.Unit;

[TestFixture]
public class LocatorGeneratorTests
{
    private LocatorGenerator _generator = null!;
    private InspectorOptions _options = null!;

    [SetUp]
    public void SetUp()
    {
        _generator = new LocatorGenerator();
        _options = new InspectorOptions();
    }

    [Test]
    public void GenerateCandidates_ButtonWithAccessibleName_ProducesRoleCandidate()
    {
        var element = ElementFactory.Create(role: "button", accessibleName: "Login");

        var candidates = _generator.GenerateCandidates(element, _options);

        var role = candidates.Single(c => c.Strategy == LocatorStrategyType.Role);
        Assert.That(role.CSharpExpression, Is.EqualTo("Page.GetByRole(AriaRole.Button, new() { Name = \"Login\" })"));
    }

    [Test]
    public void GenerateCandidates_GenericRole_DoesNotProduceRoleCandidate()
    {
        var element = ElementFactory.Create(tag: "div", role: "generic", accessibleName: null);

        var candidates = _generator.GenerateCandidates(element, _options);

        Assert.That(candidates.Any(c => c.Strategy == LocatorStrategyType.Role), Is.False);
    }

    [Test]
    public void GenerateCandidates_WithLabelText_ProducesLabelCandidate()
    {
        var element = ElementFactory.Create(tag: "input", role: "textbox", accessibleName: null, labelText: "Username");

        var candidates = _generator.GenerateCandidates(element, _options);

        var label = candidates.Single(c => c.Strategy == LocatorStrategyType.Label);
        Assert.That(label.CSharpExpression, Is.EqualTo("Page.GetByLabel(\"Username\")"));
    }

    [Test]
    public void GenerateCandidates_DefaultTestIdAttribute_UsesGetByTestId()
    {
        var element = ElementFactory.Create(testIdAttributeName: "data-testid", testIdValue: "login-button");

        var candidates = _generator.GenerateCandidates(element, _options);

        var testId = candidates.Single(c => c.Strategy == LocatorStrategyType.TestId);
        Assert.That(testId.CSharpExpression, Is.EqualTo("Page.GetByTestId(\"login-button\")"));
    }

    [Test]
    public void GenerateCandidates_NonDefaultTestIdAttribute_UsesAttributeSelectorNotGetByTestId()
    {
        var element = ElementFactory.Create(testIdAttributeName: "data-qa", testIdValue: "login-button");

        var candidates = _generator.GenerateCandidates(element, _options);

        Assert.That(candidates.Any(c => c.Strategy == LocatorStrategyType.TestId), Is.False);
        var attr = candidates.Single(c => c.Strategy == LocatorStrategyType.CssAttribute && c.AttributeName == "data-qa");
        Assert.That(attr.CSharpExpression, Is.EqualTo("Page.Locator(\"[data-qa='login-button']\")"));
    }

    [Test]
    public void GenerateCandidates_WithPlaceholder_ProducesPlaceholderCandidate()
    {
        var element = ElementFactory.Create(tag: "input", role: "textbox", accessibleName: null, placeholder: "Enter username");

        var candidates = _generator.GenerateCandidates(element, _options);

        var placeholder = candidates.Single(c => c.Strategy == LocatorStrategyType.Placeholder);
        Assert.That(placeholder.CSharpExpression, Is.EqualTo("Page.GetByPlaceholder(\"Enter username\")"));
    }

    [Test]
    public void GenerateCandidates_ShortText_ProducesTextCandidate()
    {
        var element = ElementFactory.Create(tag: "span", role: null, accessibleName: null, text: "Welcome back");

        var candidates = _generator.GenerateCandidates(element, _options);

        Assert.That(candidates.Any(c => c.Strategy == LocatorStrategyType.Text), Is.True);
    }

    [Test]
    public void GenerateCandidates_LongText_DoesNotProduceTextCandidate()
    {
        var longText = new string('a', 100);
        var element = ElementFactory.Create(tag: "span", role: null, accessibleName: null, text: longText);

        var candidates = _generator.GenerateCandidates(element, _options);

        Assert.That(candidates.Any(c => c.Strategy == LocatorStrategyType.Text), Is.False);
    }

    [Test]
    public void GenerateCandidates_WithId_ProducesCssIdCandidate()
    {
        var element = ElementFactory.Create(id: "login-btn");

        var candidates = _generator.GenerateCandidates(element, _options);

        var cssId = candidates.Single(c => c.Strategy == LocatorStrategyType.CssId);
        Assert.That(cssId.CSharpExpression, Is.EqualTo("Page.Locator(\"#login-btn\")"));
    }

    [Test]
    public void GenerateCandidates_AlwaysProducesXPathFallback()
    {
        var element = ElementFactory.Create(role: null, accessibleName: null, absoluteXPath: "/html/body[1]/div[2]");

        var candidates = _generator.GenerateCandidates(element, _options);

        var xpath = candidates.Single(c => c.Strategy == LocatorStrategyType.XPath);
        Assert.That(xpath.CSharpExpression, Does.Contain("xpath=/html/body[1]/div[2]"));
    }

    [Test]
    public void GenerateCandidates_InSubFrame_UsesFrameLocatorPrefix()
    {
        var frame = new FrameContext(false, "payment", "https://payments.example.test/", new[] { "payment" }, "iframe[name='payment']");
        var element = ElementFactory.Create(role: "button", accessibleName: "Pay", frame: frame);

        var candidates = _generator.GenerateCandidates(element, _options);

        var role = candidates.Single(c => c.Strategy == LocatorStrategyType.Role);
        Assert.That(role.CSharpExpression, Does.StartWith("Page.FrameLocator(\"iframe[name='payment']\").GetByRole"));
    }

    [Test]
    public void GenerateCandidates_DuplicateAccessibleNames_StillProducesConsistentRoleCandidate()
    {
        var first = ElementFactory.Create(role: "button", accessibleName: "Submit", internalId: "0:1");
        var second = ElementFactory.Create(role: "button", accessibleName: "Submit", internalId: "0:2");

        var firstCandidates = _generator.GenerateCandidates(first, _options);
        var secondCandidates = _generator.GenerateCandidates(second, _options);

        var firstRole = firstCandidates.Single(c => c.Strategy == LocatorStrategyType.Role);
        var secondRole = secondCandidates.Single(c => c.Strategy == LocatorStrategyType.Role);
        Assert.That(firstRole.CSharpExpression, Is.EqualTo(secondRole.CSharpExpression));
    }
}
