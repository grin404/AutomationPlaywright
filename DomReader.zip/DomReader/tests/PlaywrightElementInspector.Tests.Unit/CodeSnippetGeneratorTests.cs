using PlaywrightElementInspector.Application.Models;
using PlaywrightElementInspector.Application.Services;
using PlaywrightElementInspector.Tests.Unit.TestHelpers;

namespace PlaywrightElementInspector.Tests.Unit;

[TestFixture]
public class CodeSnippetGeneratorTests
{
    private CodeSnippetGenerator _generator = null!;

    [SetUp]
    public void SetUp() => _generator = new CodeSnippetGenerator();

    private static LocatorCandidate RoleCandidate() => new()
    {
        Strategy = LocatorStrategyType.Role,
        CSharpExpression = "Page.GetByRole(AriaRole.Button, new() { Name = \"Login\" })",
        MatchValue = "Login",
        Frame = FrameContextExtensions.MainFrame("https://example.test/"),
        BaselineScore = 100,
        Score = 100
    };

    [Test]
    public void GenerateLocatorOnly_ReturnsRawExpression()
    {
        var text = _generator.GenerateLocatorOnly(RoleCandidate());
        Assert.That(text, Is.EqualTo("Page.GetByRole(AriaRole.Button, new() { Name = \"Login\" })"));
    }

    [Test]
    public void GenerateAction_Button_UsesClickAsync()
    {
        var element = ElementFactory.Create(tag: "button");
        var text = _generator.GenerateAction(RoleCandidate(), element);

        Assert.That(text, Is.EqualTo("await Page.GetByRole(AriaRole.Button, new() { Name = \"Login\" }).ClickAsync();"));
    }

    [Test]
    public void GenerateAction_TextInput_UsesFillAsync()
    {
        var element = ElementFactory.Create(tag: "input", inputType: "text", role: "textbox");
        var text = _generator.GenerateAction(RoleCandidate(), element);

        Assert.That(text, Does.Contain(".FillAsync("));
    }

    [Test]
    public void GenerateAction_PasswordInput_UsesPlaceholderNotRealValue()
    {
        var element = ElementFactory.Create(tag: "input", inputType: "password", role: "textbox", isPasswordInput: true);
        var text = _generator.GenerateAction(RoleCandidate(), element);

        Assert.That(text, Does.Contain("REPLACE_WITH_SECRET"));
    }

    [Test]
    public void GenerateAction_Checkbox_UsesCheckAsync()
    {
        var element = ElementFactory.Create(tag: "input", inputType: "checkbox", role: "checkbox");
        var text = _generator.GenerateAction(RoleCandidate(), element);

        Assert.That(text, Does.Contain(".CheckAsync("));
    }

    [Test]
    public void GenerateNUnitTest_ProducesSelfContainedRunnableTest()
    {
        var element = ElementFactory.Create(tag: "button");
        var text = _generator.GenerateNUnitTest("LoginTests", "https://example.test/login", RoleCandidate(), element);

        Assert.That(text, Does.Contain("[TestFixture]"));
        Assert.That(text, Does.Contain("[Test]"));
        Assert.That(text, Does.Contain("await _page.GotoAsync(\"https://example.test/login\");"));
        Assert.That(text, Does.Contain("_page.GetByRole"));
        Assert.That(text, Does.Not.Contain("Page.GetByRole")); // must be adapted to the local _page variable
    }
}
