using PlaywrightElementInspector.Application.Models;
using PlaywrightElementInspector.Application.Services;
using PlaywrightElementInspector.Tests.Unit.TestHelpers;

namespace PlaywrightElementInspector.Tests.Unit;

[TestFixture]
public class LocatorScorerTests
{
    private LocatorScorer _scorer = null!;
    private InspectedElement _element = null!;

    [SetUp]
    public void SetUp()
    {
        _scorer = new LocatorScorer();
        _element = ElementFactory.Create();
    }

    private static LocatorCandidate MakeCandidate(LocatorStrategyType strategy, string matchValue, int baselineScore, string? attributeName = null) =>
        new()
        {
            Strategy = strategy,
            CSharpExpression = "Page.Locator(\"x\")",
            MatchValue = matchValue,
            AttributeName = attributeName,
            Frame = FrameContextExtensions.MainFrame("https://example.test/"),
            BaselineScore = baselineScore
        };

    [Test]
    public void Score_TargetNotMatched_ScoresZeroAndAvoid()
    {
        var candidate = MakeCandidate(LocatorStrategyType.Role, "Login", 100);
        var validation = new LocatorValidationResult { Resolved = true, MatchCount = 1, TargetMatched = false };

        _scorer.Score(candidate, _element, validation);

        Assert.That(candidate.Score, Is.EqualTo(0));
        Assert.That(candidate.Recommendation, Is.EqualTo(RecommendationLevel.Avoid));
    }

    [Test]
    public void Score_StaleElement_ScoresZero()
    {
        var candidate = MakeCandidate(LocatorStrategyType.Role, "Login", 100);
        var validation = new LocatorValidationResult { Resolved = false, IsStale = true };

        _scorer.Score(candidate, _element, validation);

        Assert.That(candidate.Score, Is.EqualTo(0));
    }

    [Test]
    public void Score_UniqueMatch_NoPenalty()
    {
        var candidate = MakeCandidate(LocatorStrategyType.Role, "Login", 100);
        var validation = new LocatorValidationResult { Resolved = true, MatchCount = 1, TargetMatched = true, IsVisible = true, IsEnabled = true };

        _scorer.Score(candidate, _element, validation);

        Assert.That(candidate.Score, Is.EqualTo(100));
        Assert.That(candidate.Recommendation, Is.EqualTo(RecommendationLevel.High));
    }

    [Test]
    public void Score_SevenMatches_HeavilyPenalized()
    {
        var candidate = MakeCandidate(LocatorStrategyType.CssClass, "button.btn", 40);
        var validation = new LocatorValidationResult { Resolved = true, MatchCount = 7, TargetMatched = true, IsVisible = true, IsEnabled = true };

        _scorer.Score(candidate, _element, validation);

        Assert.That(candidate.Score, Is.EqualTo(0)); // 40 - 40, clamped to 0
    }

    [Test]
    public void Score_GeneratedLookingId_PenalizedAndFlagged()
    {
        var candidate = MakeCandidate(LocatorStrategyType.CssId, "#element-938472", 70);

        _scorer.Score(candidate, _element, null);

        Assert.That(candidate.Score, Is.EqualTo(40)); // 70 - 30
        Assert.That(candidate.ScoreReasons, Has.Some.Contains("auto-generated"));
    }

    [Test]
    public void Score_NthChildSelector_PenalizedForPositionalFragility()
    {
        var candidate = MakeCandidate(LocatorStrategyType.CssClass, "div:nth-child(4) > span:nth-child(2)", 40);

        _scorer.Score(candidate, _element, null);

        Assert.That(candidate.Score, Is.LessThan(40));
        Assert.That(candidate.ScoreReasons, Has.Some.Contains("sibling position"));
    }

    [Test]
    public void Score_DeepIndexedXPath_PenalizedForFragility()
    {
        var candidate = MakeCandidate(LocatorStrategyType.XPath, "/html/body[1]/div[2]/div[3]/div[1]/button[1]", 20);

        _scorer.Score(candidate, _element, null);

        Assert.That(candidate.Score, Is.EqualTo(0)); // 20 - 25 (indexed) - 10 (depth), clamped to 0
        Assert.That(candidate.Recommendation, Is.EqualTo(RecommendationLevel.Avoid));
    }

    [Test]
    public void Score_SemanticRoleCandidate_OutscoresFragileXPathForSameElement()
    {
        var roleCandidate = MakeCandidate(LocatorStrategyType.Role, "Login", 100);
        var xpathCandidate = MakeCandidate(LocatorStrategyType.XPath, "/html/body[1]/div[2]/div[3]/div[1]/button[1]", 20);
        var validation = new LocatorValidationResult { Resolved = true, MatchCount = 1, TargetMatched = true, IsVisible = true, IsEnabled = true };

        _scorer.Score(roleCandidate, _element, validation);
        _scorer.Score(xpathCandidate, _element, validation);

        Assert.That(roleCandidate.Score, Is.GreaterThan(xpathCandidate.Score));
    }

    [Test]
    public void Score_NotVisible_SmallPenalty()
    {
        var candidate = MakeCandidate(LocatorStrategyType.Role, "Login", 100);
        var validation = new LocatorValidationResult { Resolved = true, MatchCount = 1, TargetMatched = true, IsVisible = false, IsEnabled = true };

        _scorer.Score(candidate, _element, validation);

        Assert.That(candidate.Score, Is.EqualTo(95));
    }
}
