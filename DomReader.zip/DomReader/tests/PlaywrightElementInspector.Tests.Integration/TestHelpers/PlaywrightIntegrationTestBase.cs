using Microsoft.Extensions.Logging.Abstractions;
using PlaywrightElementInspector.Application.Interfaces;
using PlaywrightElementInspector.Application.Models;
using PlaywrightElementInspector.Application.Services;
using PlaywrightElementInspector.Infrastructure.BrowserManagement;
using PlaywrightElementInspector.Infrastructure.Playwright;

namespace PlaywrightElementInspector.Tests.Integration.TestHelpers;

/// <summary>
/// Shared setup for integration tests: a local static file server (no internet dependency) plus a headless
/// Chromium session driven through this application's own Infrastructure implementations — these tests
/// exercise the real inspection/generation/validation pipeline, not a hand-rolled Playwright script.
/// </summary>
[TestFixture]
public abstract class PlaywrightIntegrationTestBase
{
    protected LocalFixtureServer Server { get; private set; } = null!;
    protected IBrowserManager BrowserManager { get; private set; } = null!;
    protected IDomInspector DomInspector { get; private set; } = null!;
    protected ILocatorGenerator LocatorGenerator { get; private set; } = null!;
    protected ILocatorScorer LocatorScorer { get; private set; } = null!;
    protected ILocatorValidator LocatorValidator { get; private set; } = null!;
    protected IElementHighlighter Highlighter { get; private set; } = null!;
    protected IBrowserSession Session { get; private set; } = null!;

    [OneTimeSetUp]
    public void OneTimeSetUp()
    {
        Server = new LocalFixtureServer();
        BrowserManager = new PlaywrightBrowserManager(NullLogger<PlaywrightBrowserManager>.Instance);
        DomInspector = new PlaywrightDomInspector(NullLogger<PlaywrightDomInspector>.Instance);
        LocatorGenerator = new LocatorGenerator();
        LocatorScorer = new LocatorScorer();
        LocatorValidator = new PlaywrightLocatorValidator(NullLogger<PlaywrightLocatorValidator>.Instance);
        Highlighter = new PlaywrightElementHighlighter(NullLogger<PlaywrightElementHighlighter>.Instance);
    }

    [OneTimeTearDown]
    public void OneTimeTearDown() => Server.Dispose();

    [SetUp]
    public async Task SetUpAsync()
    {
        Session = await BrowserManager.LaunchAsync(new BrowserLaunchOptions
        {
            Browser = BrowserKind.Chromium,
            Headless = true,
            BrowserStoragePath = ResolveBrowsersPath(),
            ViewportWidth = 1280,
            ViewportHeight = 720
        });
    }

    [TearDown]
    public async Task TearDownAsync()
    {
        if (Session is not null)
        {
            await Session.CloseAsync();
        }
    }

    protected async Task<IReadOnlyList<InspectedElement>> NavigateAndInspectAsync(string fixtureFile, InspectorOptions? options = null)
    {
        options ??= new InspectorOptions { WaitStrategy = PageReadyStrategy.NetworkIdle, NetworkIdleTimeoutMs = 3000 };
        await Session.NavigateAsync(Server.UrlFor(fixtureFile), options);
        return await DomInspector.InspectAsync(Session, options);
    }

    /// <summary>Locates Playwright's browser cache: honors PLAYWRIGHT_BROWSERS_PATH if the environment sets it, else the default user-writable cache.</summary>
    private static string ResolveBrowsersPath() =>
        Environment.GetEnvironmentVariable("PLAYWRIGHT_BROWSERS_PATH") is { Length: > 0 } configured
            ? configured
            : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ms-playwright");
}
