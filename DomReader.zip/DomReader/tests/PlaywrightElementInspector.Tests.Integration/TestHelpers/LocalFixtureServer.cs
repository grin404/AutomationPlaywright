using System.Net;

namespace PlaywrightElementInspector.Tests.Integration.TestHelpers;

/// <summary>Serves the local HTML fixtures over http://127.0.0.1 so tests never touch the real internet.</summary>
public sealed class LocalFixtureServer : IDisposable
{
    private readonly HttpListener _listener;
    private readonly string _fixturesDirectory;
    private readonly CancellationTokenSource _cts = new();
    private readonly Task _listenTask;

    public string BaseUrl { get; }

    public LocalFixtureServer()
    {
        _fixturesDirectory = FindFixturesDirectory();
        var port = GetFreeTcpPort();
        BaseUrl = $"http://127.0.0.1:{port}/";

        _listener = new HttpListener();
        _listener.Prefixes.Add(BaseUrl);
        _listener.Start();

        _listenTask = Task.Run(() => ListenLoopAsync(_cts.Token));
    }

    public string UrlFor(string fixtureFileName) => BaseUrl + fixtureFileName;

    private async Task ListenLoopAsync(CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            HttpListenerContext context;
            try
            {
                context = await _listener.GetContextAsync();
            }
            catch (Exception) when (cancellationToken.IsCancellationRequested || !_listener.IsListening)
            {
                return;
            }

            _ = HandleAsync(context);
        }
    }

    private async Task HandleAsync(HttpListenerContext context)
    {
        try
        {
            var fileName = context.Request.Url?.AbsolutePath.TrimStart('/') ?? "";
            var path = Path.Combine(_fixturesDirectory, fileName);

            if (File.Exists(path))
            {
                var bytes = await File.ReadAllBytesAsync(path);
                context.Response.ContentType = "text/html; charset=utf-8";
                context.Response.ContentLength64 = bytes.Length;
                await context.Response.OutputStream.WriteAsync(bytes);
            }
            else
            {
                context.Response.StatusCode = 404;
            }
        }
        catch
        {
            context.Response.StatusCode = 500;
        }
        finally
        {
            context.Response.OutputStream.Close();
        }
    }

    private static string FindFixturesDirectory()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir is not null)
        {
            var candidate = Path.Combine(dir.FullName, "Fixtures");
            if (Directory.Exists(candidate) && File.Exists(Path.Combine(candidate, "login.html")))
            {
                return candidate;
            }

            dir = dir.Parent;
        }

        throw new DirectoryNotFoundException("Could not locate tests/Fixtures directory relative to the test output.");
    }

    private static int GetFreeTcpPort()
    {
        var listener = new System.Net.Sockets.TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        var port = ((IPEndPoint)listener.LocalEndpoint).Port;
        listener.Stop();
        return port;
    }

    public void Dispose()
    {
        _cts.Cancel();
        _listener.Stop();
        _listener.Close();
    }
}
