using PlaywrightElementInspector.Application.Models;
using PlaywrightElementInspector.Tests.Integration.TestHelpers;

namespace PlaywrightElementInspector.Tests.Integration;

[TestFixture]
public class LocatorValidationTests : PlaywrightIntegrationTestBase
{
    [Test]
    public async Task ValidateAsync_UniqueLoginButton_RoleCandidateResolvesAndMatchesTarget()
    {
        var elements = await NavigateAndInspectAsync("login.html");
        var loginButton = elements.Single(e => e.Id == "login-button");
        var options = new InspectorOptions();

        var candidates = LocatorGenerator.GenerateCandidates(loginButton, options);
        var role = candidates.Single(c => c.Strategy == LocatorStrategyType.Role);

        var validation = await LocatorValidator.ValidateAsync(Session, loginButton, role);

        Assert.That(validation.Resolved, Is.True);
        Assert.That(validation.MatchCount, Is.EqualTo(1));
        Assert.That(validation.TargetMatched, Is.True);
        Assert.That(validation.IsVisible, Is.True);
        Assert.That(validation.IsEnabled, Is.True);

        LocatorScorer.Score(role, loginButton, validation);
        Assert.That(role.Recommendation, Is.EqualTo(RecommendationLevel.High));
    }

    [Test]
    public async Task ValidateAsync_DuplicateButtonText_RoleCandidateIsAmbiguousButStillMatchesTarget()
    {
        var elements = await NavigateAndInspectAsync("accessibility.html");
        var submitButtons = elements.Where(e => e.AccessibleName == "Submit").ToList();
        Assert.That(submitButtons, Has.Count.EqualTo(2));

        var target = submitButtons[0];
        var options = new InspectorOptions();
        var candidates = LocatorGenerator.GenerateCandidates(target, options);
        var role = candidates.Single(c => c.Strategy == LocatorStrategyType.Role);

        var validation = await LocatorValidator.ValidateAsync(Session, target, role);
        LocatorScorer.Score(role, target, validation);

        Assert.That(validation.MatchCount, Is.EqualTo(2));
        Assert.That(validation.TargetMatched, Is.True);
        Assert.That(role.Score, Is.LessThan(100)); // penalized for non-uniqueness
        Assert.That(role.Recommendation, Is.Not.EqualTo(RecommendationLevel.High));
    }

    [Test]
    public async Task ValidateAsync_DuplicateLabelText_LabelCandidateIsAmbiguous()
    {
        var elements = await NavigateAndInspectAsync("accessibility.html");
        var emailInputs = elements.Where(e => e.LabelText == "Email").ToList();
        Assert.That(emailInputs, Has.Count.EqualTo(2));

        var target = emailInputs[0];
        var options = new InspectorOptions();
        var candidates = LocatorGenerator.GenerateCandidates(target, options);
        var label = candidates.Single(c => c.Strategy == LocatorStrategyType.Label);

        var validation = await LocatorValidator.ValidateAsync(Session, target, label);

        // Exact match count is a browser accessibility-tree implementation detail; what matters here is
        // that a duplicated label is correctly reported as non-unique while still resolving the target.
        Assert.That(validation.MatchCount, Is.GreaterThanOrEqualTo(2));
        Assert.That(validation.TargetMatched, Is.True);
    }

    [Test]
    public async Task ValidateAsync_DisabledButton_ReportsEnabledFalse()
    {
        var elements = await NavigateAndInspectAsync("accessibility.html");
        var disabled = elements.Single(e => e.Id == "disabled-button");
        var options = new InspectorOptions();
        var candidates = LocatorGenerator.GenerateCandidates(disabled, options);
        var cssId = candidates.Single(c => c.Strategy == LocatorStrategyType.CssId);

        var validation = await LocatorValidator.ValidateAsync(Session, disabled, cssId);

        Assert.That(validation.TargetMatched, Is.True);
        Assert.That(validation.IsEnabled, Is.False);
    }

    [Test]
    public async Task ValidateAsync_HiddenElement_ReportsVisibleFalseAndInspectorFlagsIt()
    {
        var elements = await NavigateAndInspectAsync("accessibility.html");
        var hidden = elements.SingleOrDefault(e => e.Id == "hidden-button");

        // The walker still captures hidden elements (id present) but must flag them as not visible.
        Assert.That(hidden, Is.Not.Null);
        Assert.That(hidden!.IsVisible, Is.False);
    }

    [Test]
    public async Task ValidateAsync_XPathFallback_StillMatchesTargetForUniqueElement()
    {
        var elements = await NavigateAndInspectAsync("login.html");
        var loginButton = elements.Single(e => e.Id == "login-button");
        var options = new InspectorOptions();
        var candidates = LocatorGenerator.GenerateCandidates(loginButton, options);
        var xpath = candidates.Single(c => c.Strategy == LocatorStrategyType.XPath);

        var validation = await LocatorValidator.ValidateAsync(Session, loginButton, xpath);

        Assert.That(validation.Resolved, Is.True);
        Assert.That(validation.TargetMatched, Is.True);
    }
}
