using PlaywrightElementInspector.Application.Models;
using PlaywrightElementInspector.Tests.Integration.TestHelpers;

namespace PlaywrightElementInspector.Tests.Integration;

[TestFixture]
public class DynamicPageTests : PlaywrightIntegrationTestBase
{
    [Test]
    public async Task InspectAsync_SpaStyleInjectedContent_IsFoundAfterNetworkIdleWait()
    {
        var options = new InspectorOptions { WaitStrategy = PageReadyStrategy.NetworkIdle, NetworkIdleTimeoutMs = 5000 };
        var elements = await NavigateAndInspectAsync("dynamic.html", options);

        var saveButton = elements.SingleOrDefault(e => e.Id == "el-38291");
        Assert.That(saveButton, Is.Not.Null, "Content injected after initial load should be visible to the inspector once the page settles.");
        Assert.That(saveButton!.TestIdValue, Is.EqualTo("save-button"));
    }

    [Test]
    public async Task GenerateCandidates_DynamicIdLookingGenerated_IsPenalizedByScorer()
    {
        var options = new InspectorOptions { WaitStrategy = PageReadyStrategy.NetworkIdle, NetworkIdleTimeoutMs = 5000 };
        var elements = await NavigateAndInspectAsync("dynamic.html", options);
        var saveButton = elements.Single(e => e.Id == "el-38291");

        var candidates = LocatorGenerator.GenerateCandidates(saveButton, options).ToList();
        var cssId = candidates.Single(c => c.Strategy == LocatorStrategyType.CssId);
        LocatorScorer.Score(cssId, saveButton, null);

        Assert.That(cssId.ScoreReasons, Has.Some.Contains("auto-generated"));

        // The generated-looking id candidate should not outrank the test-id-backed candidate for the same element.
        var testId = candidates.Single(c => c.Strategy == LocatorStrategyType.TestId);
        LocatorScorer.Score(testId, saveButton, null);
        Assert.That(testId.Score, Is.GreaterThan(cssId.Score));
    }

    [Test]
    public async Task InspectAsync_RepeatedSiblingElements_AreCapturedIndividually()
    {
        var options = new InspectorOptions { WaitStrategy = PageReadyStrategy.NetworkIdle, NetworkIdleTimeoutMs = 5000, IncludeLowValueElements = true };
        var elements = await NavigateAndInspectAsync("dynamic.html", options);

        var items = elements.Where(e => e.ClassAttribute == "item").ToList();
        Assert.That(items, Has.Count.EqualTo(3));
        Assert.That(items.Select(i => i.SiblingIndexOfSameTag), Is.EquivalentTo(new[] { 1, 2, 3 }));
    }
}
