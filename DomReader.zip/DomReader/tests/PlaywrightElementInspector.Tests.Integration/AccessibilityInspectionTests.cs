using PlaywrightElementInspector.Application.Models;
using PlaywrightElementInspector.Tests.Integration.TestHelpers;

namespace PlaywrightElementInspector.Tests.Integration;

[TestFixture]
public class AccessibilityInspectionTests : PlaywrightIntegrationTestBase
{
    [Test]
    public async Task InspectAsync_AriaLabelButton_UsesAriaLabelAsAccessibleName()
    {
        var elements = await NavigateAndInspectAsync("accessibility.html");

        var closeButton = elements.Single(e => e.AriaLabel == "Close");
        Assert.That(closeButton.AccessibleName, Is.EqualTo("Close"));
    }

    [Test]
    public async Task InspectAsync_ImageWithAlt_UsesAltAsAccessibleName()
    {
        var elements = await NavigateAndInspectAsync("accessibility.html");

        var img = elements.Single(e => e.Tag == "img");
        Assert.That(img.AccessibleName, Is.EqualTo("Company Logo"));
        Assert.That(img.Role, Is.EqualTo("img"));
    }

    [Test]
    public async Task InspectAsync_ExplicitAriaRoleElement_IsCaptured()
    {
        var elements = await NavigateAndInspectAsync("accessibility.html");

        var alert = elements.Single(e => e.Role == "alert");
        Assert.That(alert.AccessibleName, Is.EqualTo("Warning banner"));
    }

    [Test]
    public async Task InspectAsync_InputWithoutLabelOrIdOrName_IsStillCapturedAsInteractive()
    {
        var elements = await NavigateAndInspectAsync("accessibility.html");

        // Plain <input type="text"> with no id/name/label is still an interactive tag, so it's included
        // — but has no strong locator candidates besides role/xpath, which the scorer should reflect.
        var unlabeled = elements.Where(e => e.Tag == "input" && e.Id is null && e.Name is null).ToList();
        Assert.That(unlabeled, Has.Count.EqualTo(1));

        var candidates = LocatorGenerator.GenerateCandidates(unlabeled[0], new InspectorOptions());
        Assert.That(candidates.Any(c => c.Strategy == LocatorStrategyType.XPath), Is.True);
        Assert.That(candidates.Any(c => c.Strategy == LocatorStrategyType.CssId), Is.False);
    }

    [Test]
    public async Task InspectAsync_EmptyClassAttribute_DoesNotProduceUselessClassCandidate()
    {
        var elements = await NavigateAndInspectAsync("accessibility.html", new InspectorOptions { IncludeLowValueElements = true });

        var div = elements.Single(e => e.Id == "empty-class-div");
        var candidates = LocatorGenerator.GenerateCandidates(div, new InspectorOptions());

        Assert.That(candidates.Any(c => c.Strategy == LocatorStrategyType.CssClass), Is.False);
    }
}
