using PlaywrightElementInspector.Application.Models;
using PlaywrightElementInspector.Tests.Integration.TestHelpers;

namespace PlaywrightElementInspector.Tests.Integration;

[TestFixture]
public class FrameInspectionTests : PlaywrightIntegrationTestBase
{
    [Test]
    public async Task InspectAsync_PageWithIframe_FindsElementsInBothMainFrameAndIframe()
    {
        var elements = await NavigateAndInspectAsync("iframe.html");

        var mainButton = elements.Single(e => e.Id == "continue-button");
        Assert.That(mainButton.Frame.IsMainFrame, Is.True);

        var frameButton = elements.Single(e => e.Id == "pay-button");
        Assert.That(frameButton.Frame.IsMainFrame, Is.False);
        Assert.That(frameButton.Frame.Name, Is.EqualTo("payment"));
    }

    [Test]
    public async Task InspectAsync_IframeElement_FrameSelectorHintIdentifiesTheFrameByName()
    {
        var elements = await NavigateAndInspectAsync("iframe.html");
        var frameButton = elements.Single(e => e.Id == "pay-button");

        Assert.That(frameButton.Frame.SelectorHint, Does.Contain("payment"));
    }

    [Test]
    public async Task GenerateCandidates_IframeElement_ProducesFrameLocatorPrefixedExpression()
    {
        var elements = await NavigateAndInspectAsync("iframe.html");
        var frameButton = elements.Single(e => e.Id == "pay-button");
        var candidates = LocatorGenerator.GenerateCandidates(frameButton, new InspectorOptions());

        var role = candidates.Single(c => c.Strategy == LocatorStrategyType.Role);
        Assert.That(role.CSharpExpression, Does.StartWith("Page.FrameLocator("));
        Assert.That(role.CSharpExpression, Does.Contain("GetByRole"));
    }

    [Test]
    public async Task ValidateAsync_IframeElement_ResolvesAndMatchesTargetInsideTheFrame()
    {
        var elements = await NavigateAndInspectAsync("iframe.html");
        var frameButton = elements.Single(e => e.Id == "pay-button");
        var candidates = LocatorGenerator.GenerateCandidates(frameButton, new InspectorOptions());
        var testId = candidates.Single(c => c.Strategy == LocatorStrategyType.TestId);

        var validation = await LocatorValidator.ValidateAsync(Session, frameButton, testId);

        Assert.That(validation.Resolved, Is.True);
        Assert.That(validation.TargetMatched, Is.True);
        Assert.That(validation.MatchCount, Is.EqualTo(1));
    }
}
