using PlaywrightElementInspector.Application.Models;
using PlaywrightElementInspector.Tests.Integration.TestHelpers;

namespace PlaywrightElementInspector.Tests.Integration;

[TestFixture]
public class ShadowDomInspectionTests : PlaywrightIntegrationTestBase
{
    [Test]
    public async Task InspectAsync_OpenShadowRoot_FindsElementInsideIt()
    {
        var elements = await NavigateAndInspectAsync("shadow-dom.html");

        var shadowButton = elements.Single(e => e.Id == "shadow-button");
        Assert.That(shadowButton.IsInShadowDom, Is.True);
        Assert.That(shadowButton.ShadowHostDescription, Does.Contain("widget-host"));
    }

    [Test]
    public async Task ValidateAsync_ElementInsideOpenShadowRoot_LocatorStillResolves()
    {
        var elements = await NavigateAndInspectAsync("shadow-dom.html");
        var shadowButton = elements.Single(e => e.Id == "shadow-button");
        var candidates = LocatorGenerator.GenerateCandidates(shadowButton, new InspectorOptions());
        var testId = candidates.Single(c => c.Strategy == LocatorStrategyType.TestId);

        var validation = await LocatorValidator.ValidateAsync(Session, shadowButton, testId);

        // Playwright's locators pierce open shadow roots natively.
        Assert.That(validation.Resolved, Is.True);
        Assert.That(validation.TargetMatched, Is.True);
    }
}
