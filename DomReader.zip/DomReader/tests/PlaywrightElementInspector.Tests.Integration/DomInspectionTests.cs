using PlaywrightElementInspector.Application.Models;
using PlaywrightElementInspector.Tests.Integration.TestHelpers;

namespace PlaywrightElementInspector.Tests.Integration;

[TestFixture]
public class DomInspectionTests : PlaywrightIntegrationTestBase
{
    [Test]
    public async Task InspectAsync_LoginPage_FindsButtonInputsAndLabels()
    {
        var elements = await NavigateAndInspectAsync("login.html");

        var loginButton = elements.Single(e => e.Id == "login-button");
        Assert.That(loginButton.Tag, Is.EqualTo("button"));
        Assert.That(loginButton.Role, Is.EqualTo("button"));
        Assert.That(loginButton.AccessibleName, Is.EqualTo("Login"));
        Assert.That(loginButton.TestIdAttributeName, Is.EqualTo("data-testid"));
        Assert.That(loginButton.TestIdValue, Is.EqualTo("login-button"));

        var usernameInput = elements.Single(e => e.Id == "username-field");
        Assert.That(usernameInput.LabelText, Is.EqualTo("Username"));
        Assert.That(usernameInput.Placeholder, Is.EqualTo("Enter username"));
    }

    [Test]
    public async Task InspectAsync_PasswordField_NeverCapturesItsValue()
    {
        var elements = await NavigateAndInspectAsync("login.html");

        var password = elements.Single(e => e.Id == "password-field");
        Assert.That(password.IsPasswordInput, Is.True);
        Assert.That(password.Attributes.ContainsKey("value"), Is.False);
    }

    [Test]
    public async Task InspectAsync_ByDefault_ExcludesStructuralOnlyElements()
    {
        var elements = await NavigateAndInspectAsync("login.html");

        // <form> and <html>/<body> wrappers carry no id/name/role/test-attr and should not appear by default.
        Assert.That(elements.Any(e => e.Tag == "form"), Is.False);
    }

    [Test]
    public async Task InspectAsync_IncludeLowValueElements_IncludesStructuralWrappers()
    {
        var options = new InspectorOptions { IncludeLowValueElements = true };
        var elements = await NavigateAndInspectAsync("login.html", options);

        Assert.That(elements.Any(e => e.Tag == "form"), Is.True);
    }

    [Test]
    public async Task InspectAsync_EachElement_HasNonEmptyAbsoluteXPath()
    {
        var elements = await NavigateAndInspectAsync("login.html");

        Assert.That(elements, Is.Not.Empty);
        Assert.That(elements.All(e => !string.IsNullOrWhiteSpace(e.AbsoluteXPath)), Is.True);
    }
}
